#!/data/data/com.legitiv.linux/files/usr/bin/bash
set -euo pipefail
BASE="$HOME/.legitiv"
mkdir -p "$BASE" "$PREFIX/bin"

pkg update -y || true
pkg install -y proot-distro python git wget curl || true

cat > "$PREFIX/bin/legitiv-setup" <<'SETUP'
#!/data/data/com.legitiv.linux/files/usr/bin/bash
set -euo pipefail
DISTRO="${1:-ubuntu}"
case "$DISTRO" in
ubuntu|debian)
  proot-distro login "$DISTRO" --shared-tmp -- bash -lc '
    export DEBIAN_FRONTEND=noninteractive
    apt update
    apt install -y xfce4 xfce4-terminal thunar dbus-x11 tigervnc-standalone-server vlc ca-certificates
    mkdir -p ~/.vnc
    cat > ~/.vnc/xstartup <<"XSTART"
#!/bin/sh
unset SESSION_MANAGER
unset DBUS_SESSION_BUS_ADDRESS
export XDG_RUNTIME_DIR=/tmp/runtime-$(id -u)
mkdir -p "$XDG_RUNTIME_DIR"
chmod 700 "$XDG_RUNTIME_DIR"
exec dbus-launch --exit-with-session startxfce4
XSTART
    chmod +x ~/.vnc/xstartup
    echo DESKTOP_SETUP_OK
  '
  ;;
alpine)
  proot-distro login alpine --shared-tmp -- sh -lc 'apk update; apk add xfce4 xfce4-terminal thunar dbus dbus-x11 tigervnc; echo DESKTOP_SETUP_OK'
  ;;
kali)
  echo "Use legitive-kali-setup after official NetHunter Rootless installation."
  ;;
*) echo "Unsupported distro"; exit 2;;
esac
SETUP
chmod +x "$PREFIX/bin/legitiv-setup"

cat > "$PREFIX/bin/legitiv-desktop" <<'DESKTOP'
#!/data/data/com.legitiv.linux/files/usr/bin/bash
set -euo pipefail
DISTRO="${1:-ubuntu}"
proot-distro login "$DISTRO" --shared-tmp -- bash -lc '
  test -f ~/.vnc/passwd || { echo VNC_PASSWORD_REQUIRED; exit 10; }
  vncserver -kill :1 >/dev/null 2>&1 || true
  rm -f /tmp/.X1-lock /tmp/.X11-unix/X1 || true
  vncserver :1 -geometry 1366x768 -depth 24 -localhost
'
if ! pgrep -f 'websockify.*6080' >/dev/null 2>&1; then
  python -m websockify 6080 127.0.0.1:5901 >/tmp/legitiv-websockify.log 2>&1 &
fi
echo DESKTOP_READY
DESKTOP
chmod +x "$PREFIX/bin/legitiv-desktop"

cat > "$PREFIX/bin/legitiv-app" <<'APP'
#!/data/data/com.legitiv.linux/files/usr/bin/bash
set -euo pipefail
DISTRO="${1:-ubuntu}"; APP="${2:-xfce4-terminal}"
case "$APP" in
  vlc|thunar|xfce4-terminal|openttd|supertux2) ;;
  *) echo "Allowed demo apps: vlc, thunar, xfce4-terminal, openttd, supertux2"; exit 2;;
esac
proot-distro login "$DISTRO" --shared-tmp -- bash -lc "export DISPLAY=:1; nohup $APP >/tmp/legitiv-$APP.log 2>&1 </dev/null &"
APP
chmod +x "$PREFIX/bin/legitiv-app"

cat > "$PREFIX/bin/legitiv-kali-install" <<'KALI'
#!/data/data/com.legitiv.linux/files/usr/bin/bash
set -euo pipefail
pkg install -y wget
cd "$HOME/.legitiv"
if [ ! -x ./install-nethunter-termux ]; then
  wget -O install-nethunter-termux https://offs.ec/2MceZWr
  chmod +x install-nethunter-termux
fi
./install-nethunter-termux
KALI
chmod +x "$PREFIX/bin/legitiv-kali-install"

cat > "$PREFIX/bin/legitiv-kali-setup" <<'KSETUP'
#!/data/data/com.legitiv.linux/files/usr/bin/bash
set -euo pipefail
if command -v nethunter >/dev/null 2>&1; then
  nethunter -r apt update
  nethunter -r apt install -y xfce4 xfce4-terminal tigervnc-standalone-server dbus-x11 vlc thunar
  echo KALI_SETUP_OK
else
  echo "Kali NetHunter Rootless is not installed yet. Run legitive-kali-install."
  exit 20
fi
KSETUP
chmod +x "$PREFIX/bin/legitiv-kali-setup"

echo LEGITIV_TERMUX_SETUP_OK

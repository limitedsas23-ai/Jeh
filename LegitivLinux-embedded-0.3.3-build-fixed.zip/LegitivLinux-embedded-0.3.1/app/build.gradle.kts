plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.legitiv.linux"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.legitiv.linux"
        minSdk = 26
        targetSdk = 36
        versionCode = 30
        versionName = "0.3.0"
    }

    buildFeatures { compose = true }

    packaging {
        jniLibs.useLegacyPackaging = true
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation(platform("androidx.compose:compose-bom:2024.05.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material:material-icons-extended")

    // Embedded Termux runtime + distro/desktop module.
    // This is an experimental GitHub project pinned in the research notes.
    implementation("com.github.libtermux:libtermux-android:1.0.0")
    implementation("com.github.libtermux:libtermux-os:1.0.0")
    implementation("com.github.libtermux:terminal-view:1.0.0")

    // Bundle the ARM64 Termux bootstrap into the APK, so the user does not
    // install a separate Termux app and the core bootstrap is available at install time.
    implementation("com.github.libtermux:libtermux-android-bootstrap-arm64:1.0.0")
}

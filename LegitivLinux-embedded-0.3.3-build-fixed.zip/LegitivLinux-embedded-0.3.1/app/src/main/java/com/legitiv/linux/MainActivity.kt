package com.legitiv.linux

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.libtermux.LibTermux
import com.libtermux.LogLevel
import com.libtermux.bootstrap.InstallState
import com.libtermux.bootstrap.NativeLibBootstrapProvider
import com.libtermux.os.createOs
import com.libtermux.os.distro.Distro
import com.libtermux.os.gui.DesktopSession
import com.libtermux.os.gui.compose.DistroDisplay
import com.libtermux.os.registry.DesktopEnvironment
import com.libtermux.os.registry.DisplayResolution
import com.libtermux.os.settings.DistroRuntimeSettings
import com.libtermux.view.TerminalView
import kotlinx.coroutines.launch

private data class Profile(
    val id: String,
    val name: String,
    val distro: Distro,
    val description: String,
    val gui: Boolean,
    val packages: List<String>
)

class MainActivity : ComponentActivity() {
    private val termux by lazy {
        LibTermux.init(applicationContext) {
            autoInstall = true
            logLevel = LogLevel.INFO
            backgroundExecutionEnabled = true
            bootstrapProvider = NativeLibBootstrapProvider.from(applicationContext)
            env("COLORTERM", "truecolor")
        }
    }

    private val os by lazy {
        termux.createOs {
            executionMode = com.libtermux.os.ExecutionMode.PROOT
            bindSdCard = true
            fakeRoot = true
            registry {
                distro(Distro.Ubuntu2404) {
                    guiEnabled = true
                    desktopEnvironment = DesktopEnvironment.XFCE4
                    defaultResolution = DisplayResolution.HD_720P
                    description = "Ubuntu 24.04 LTS + XFCE4"
                    extraPackages = listOf("git", "curl", "wget", "python3", "python3-pip", "vlc", "thunar")
                }
                distro(Distro.Debian12) {
                    guiEnabled = true
                    desktopEnvironment = DesktopEnvironment.XFCE4
                    defaultResolution = DisplayResolution.HD_720P
                    description = "Debian 12 Bookworm + XFCE4"
                    extraPackages = listOf("git", "curl", "wget", "python3", "python3-pip", "vlc", "thunar")
                }
                distro(Distro.Alpine) {
                    guiEnabled = true
                    desktopEnvironment = DesktopEnvironment.XFCE4
                    defaultResolution = DisplayResolution.SMALL_800P
                    description = "Минимальный Alpine Linux"
                    extraPackages = listOf("bash", "curl", "git", "python3")
                }
                distro(Distro.Kali) {
                    guiEnabled = true
                    desktopEnvironment = DesktopEnvironment.XFCE4
                    defaultResolution = DisplayResolution.HD_720P
                    description = "Kali Linux / NetHunter rootless-профиль"
                    extraPackages = listOf("git", "curl", "wget", "python3")
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LegitivTheme { LegitivApp() } }
    }

    @Composable
    private fun LegitivTheme(content: @Composable () -> Unit) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                background = Color(0xFF0D1117),
                surface = Color(0xFF161B22),
                primary = Color(0xFF58A6FF)
            ),
            content = content
        )
    }

    @Composable
    private fun LegitivApp() {
        var tab by remember { mutableIntStateOf(0) }
        var selected by remember { mutableStateOf(Distro.Ubuntu2404.id) }
        var session by remember { mutableStateOf<DesktopSession?>(null) }
        var status by remember { mutableStateOf("Готово. Встроенный Termux ещё не инициализирован.") }
        var desktopLoading by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()

        val profiles = remember {
            listOf(
                Profile("ubuntu", "Ubuntu 24.04", Distro.Ubuntu2404, "Полноценная Ubuntu-среда для разработки", true, listOf("git", "python3", "vlc", "thunar")),
                Profile("debian", "Debian 12", Distro.Debian12, "Стабильная Debian-среда", true, listOf("git", "python3", "vlc", "thunar")),
                Profile("alpine", "Alpine", Distro.Alpine, "Минимальный и лёгкий Linux", true, listOf("git", "python3")),
                Profile("kali", "Kali", Distro.Kali, "Профиль NetHunter Rootless", true, listOf("git", "python3"))
            )
        }
        val current = profiles.first { it.id == selected }

        Scaffold(
            containerColor = Color(0xFF0D1117),
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF161B22)) {
                    NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.PlayArrow, null) }, label = { Text("Linux") })
                    NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.Terminal, null) }, label = { Text("Terminal") })
                    NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.Computer, null) }, label = { Text("Desktop") })
                    NavigationBarItem(tab == 3, { tab = 3 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Настройки") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> LinuxScreen(
                    Modifier.padding(padding), profiles, current, status,
                    onSelect = { selected = it },
                    onBootstrap = {
                        scope.launch {
                            termux.initialize().collect { s ->
                                status = when (s) {
                                    is InstallState.Checking -> "Проверка встроенного Termux…"
                                    is InstallState.AlreadyInstalled -> "Встроенный Termux уже готов ✓"
                                    is InstallState.Downloading -> "Неожиданная загрузка bootstrap: ${(s.progress * 100).toInt()}%"
                                    is InstallState.Extracting -> "Подготовка встроенного runtime…"
                                    is InstallState.Completed -> "Встроенный Termux готов ✓"
                                    is InstallState.Failed -> "Ошибка: ${s.error}"
                                    else -> "Инициализация…"
                                }
                            }
                        }
                    },
                    onInstall = {
                        scope.launch {
                            if (!termux.isInstalled) {
                                status = "Сначала подготовьте встроенный Termux."
                                return@launch
                            }
                            status = "Установка ${current.name}…"
                            os.setupDistro(current.distro).collect { s -> status = s.toString() }
                            status = "${current.name} готов." 
                        }
                    },
                    onDesktop = {
                        scope.launch {
                            try {
                                if (!termux.isInstalled) {
                                    status = "Сначала запустите встроенный Termux."
                                    return@launch
                                }
                                if (!os.isInstalled(current.distro)) {
                                    status = "Сначала установите ${current.name}."
                                    return@launch
                                }
                                desktopLoading = true
                                val s = os.createDesktopSession(current.distro)
                                val sd = os.registry[current.distro]!!
                                s.start(
                                    DistroRuntimeSettings(
                                        distroId = current.distro.id,
                                        displayWidth = sd.effectiveWidth,
                                        displayHeight = sd.effectiveHeight,
                                        colorDepth = sd.colorDepth,
                                        vncPort = sd.vncPort,
                                        vncPassword = sd.vncPassword ?: "",
                                        showToolbar = true,
                                        scaleToFit = true
                                    )
                                )
                                session = s
                                tab = 2
                                status = "Запуск ${current.name} desktop…"
                            } catch (e: Exception) {
                                status = "Desktop error: ${e.message}"
                            } finally {
                                desktopLoading = false
                            }
                        }
                    }
                )
                1 -> TerminalScreen(termux)
                2 -> DesktopScreen(session, onClose = {
                    scope.launch { session?.stop() }
                    session = null
                    tab = 0
                }, loading = desktopLoading)
                3 -> SettingsScreen()
            }
        }
    }

    @Composable
    private fun LinuxScreen(
        modifier: Modifier,
        profiles: List<Profile>,
        current: Profile,
        status: String,
        onSelect: (String) -> Unit,
        onBootstrap: () -> Unit,
        onInstall: () -> Unit,
        onDesktop: () -> Unit
    ) {
        LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text("LEGITIV LINUX", style = MaterialTheme.typography.headlineMedium, color = Color.White) }
            item { Text("Один APK → встроенный Termux → Linux → VNC desktop", color = Color.LightGray) }
            item {
                Text("Дистрибутив", style = MaterialTheme.typography.titleMedium, color = Color.White)
                profiles.forEach { p ->
                    FilterChip(
                        selected = current.id == p.id,
                        onClick = { onSelect(p.id) },
                        label = { Text(p.name) },
                        modifier = Modifier.padding(end = 6.dp, top = 6.dp)
                    )
                }
            }
            item { Card { Column(Modifier.padding(14.dp)) { Text(current.name, style = MaterialTheme.typography.titleLarge); Text(current.description, color = Color.LightGray) } } }
            item { Button(onClick = onBootstrap, Modifier.fillMaxWidth()) { Text("1. Инициализировать встроенный Termux") } }
            item { Button(onClick = onInstall, Modifier.fillMaxWidth()) { Text("2. Установить ${current.name}") } }
            item { Button(onClick = onDesktop, Modifier.fillMaxWidth()) { Text("3. Запустить Linux Desktop внутри Legitiv") } }
            item { Text("Статус", style = MaterialTheme.typography.titleMedium, color = Color.White) }
            item { Text(status, color = Color(0xFFB7C1D1)) }
            item { Text("Программы ставятся внутри выбранного Linux. VLC, Thunar, Python и другие пакеты доступны после установки соответствующих пакетов.", color = Color(0xFF8B949E)) }
        }
    }

    @Composable
    private fun TerminalScreen(termux: LibTermux) {
        var created by remember { mutableStateOf(false) }
        Column(Modifier.fillMaxSize().background(Color.Black).padding(4.dp)) {
            AndroidView(
                factory = { ctx ->
                    TerminalView(ctx).also { view ->
                        val s = termux.sessions.createSession("legitiv-main")
                        view.attachSession(s)
                        s.run("bash")
                        created = true
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }

    @Composable
    private fun DesktopScreen(session: DesktopSession?, onClose: () -> Unit, loading: Boolean) {
        Column(Modifier.fillMaxSize().background(Color.Black)) {
            Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onClose) { Text("← Legitiv") }
                Spacer(Modifier.width(8.dp))
                Text(session?.distro?.displayName ?: "Linux Desktop", color = Color.White)
            }
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                when {
                    loading -> CircularProgressIndicator()
                    session != null -> DistroDisplay(session = session, modifier = Modifier.fillMaxSize(), showToolbar = true, onClose = onClose)
                    else -> Text("Desktop ещё не запущен", color = Color.LightGray)
                }
            }
        }
    }

    @Composable
    private fun SettingsScreen() {
        LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text("Настройки", style = MaterialTheme.typography.headlineSmall, color = Color.White) }
            item { Text("Runtime: встроенный Termux SDK", color = Color.LightGray) }
            item { Text("Linux backend: PRoot без root", color = Color.LightGray) }
            item { Text("Desktop: TigerVNC + встроенный Kotlin RFB/VNC display", color = Color.LightGray) }
            item { Text("Bootstrap ARM64 входит в APK. Rootfs выбранного дистрибутива загружается при первом использовании.", color = Color.LightGray) }
            item { Text("Для 32-битных ARM/x86/x86_64 сборок нужно добавить соответствующий bootstrap-модуль.", color = Color.LightGray) }
        }
    }
}

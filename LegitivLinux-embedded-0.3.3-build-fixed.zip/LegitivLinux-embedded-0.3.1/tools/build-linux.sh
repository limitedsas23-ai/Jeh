#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

need_cmd() { command -v "$1" >/dev/null 2>&1; }

if ! need_cmd git || ! need_cmd unzip; then
  if need_cmd apt-get; then
    if need_cmd sudo; then
      sudo apt-get update
      sudo apt-get install -y git unzip curl ca-certificates
    else
      echo "Missing git/unzip and sudo is not available. Install them with apt." >&2
      exit 1
    fi
  else
    echo "This script expects a Debian/Ubuntu-like Linux with git, unzip and curl installed." >&2
    exit 1
  fi
fi

if ! need_cmd java; then
  if need_cmd apt-get && need_cmd sudo; then
    sudo apt-get update
    sudo apt-get install -y openjdk-21-jdk
  else
    echo "JDK 21 is required. Install OpenJDK 21 and run this script again." >&2
    exit 1
  fi
fi

JAVA_MAJOR="$(java -version 2>&1 | awk -F '[\".]' '/version/ {print $2; exit}')"
if [[ "${JAVA_MAJOR:-0}" != "21" ]]; then
  echo "JDK 21 is required; detected Java ${JAVA_MAJOR:-unknown}." >&2
  exit 1
fi

chmod +x ./gradlew ./tools/bootstrap-libtermux.sh
./tools/bootstrap-libtermux.sh

./gradlew --no-daemon --stacktrace :app:assembleDebug

APK="$(find app/build/outputs/apk/debug -maxdepth 1 -type f -name '*.apk' -print -quit)"
if [[ -z "$APK" ]]; then
  echo "Build finished but APK was not found." >&2
  exit 1
fi

echo
echo "APK готов: $ROOT/$APK"

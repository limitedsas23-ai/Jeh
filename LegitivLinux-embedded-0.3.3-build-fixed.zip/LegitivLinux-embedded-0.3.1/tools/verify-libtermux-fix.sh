#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FILE="$ROOT/vendor/libtermux/os/src/main/kotlin/com/libtermux/os/settings/DistroSettings.kt"
test -f "$FILE"
if grep -nE '\b(intKey|stringKey|booleanKey)\b' "$FILE"; then
  echo "Legacy DataStore key helpers remain in $FILE" >&2
  exit 1
fi
grep -nE 'intPreferencesKey|stringPreferencesKey|booleanPreferencesKey' "$FILE"
echo "LibTermux DataStore key helper fix is present."

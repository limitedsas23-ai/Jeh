#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VENDOR="$ROOT/vendor/libtermux"
REPO="https://github.com/libtermux/libtermux-android.git"
REF="${LIBTERMUX_REF:-main}"

mkdir -p "$ROOT/vendor"

if [[ -d "$VENDOR/.git" ]]; then
  echo "[Legitiv] Updating LibTermux source ($REF)..."
  git -C "$VENDOR" fetch --depth 1 origin "$REF"
  git -C "$VENDOR" checkout -q FETCH_HEAD
else
  echo "[Legitiv] Downloading LibTermux source ($REF)..."
  rm -rf "$VENDOR"
  git clone --depth 1 --branch "$REF" "$REPO" "$VENDOR"
fi

# Patch the current LibTermux DataStore key helper names so the fetched main branch
# matches the AndroidX Preferences DataStore API.
DS_FILE="$VENDOR/os/src/main/kotlin/com/libtermux/os/settings/DistroSettings.kt"
if [[ -f "$DS_FILE" ]]; then
  sed -i \
    -e 's/intKey/intPreferencesKey/g' \
    -e 's/stringKey/stringPreferencesKey/g' \
    -e 's/booleanKey/booleanPreferencesKey/g' \
    "$DS_FILE"
fi

printf 'LibTermux ref: %s\n' "$(git -C "$VENDOR" rev-parse HEAD)" > "$ROOT/vendor/LIBTERMUX_REF.txt"
echo "[Legitiv] LibTermux is ready: $(git -C "$VENDOR" rev-parse --short HEAD)"

# Legitiv Linux 0.3.1 — встроенный Termux / Linux / VNC

Экспериментальная Android-сборка Legitiv Linux. LibTermux подключён как исходная зависимость через Gradle composite build: перед сборкой проект получает исходники `libtermux/libtermux-android` в `vendor/libtermux`, поэтому сборка не зависит от доступности JitPack-артефактов `com.github.libtermux:*:1.0.0`.

## Архитектура

```text
Legitiv Linux APK
│
├─ LibTermux Core
│  └─ standalone Termux runtime / PTY
│
├─ TerminalView
│  └─ интерактивный терминал внутри Legitiv
│
├─ OS module + PRoot
│  ├─ Ubuntu 24.04
│  ├─ Debian 12
│  ├─ Alpine
│  └─ Kali
│
└─ DesktopSession
   └─ TigerVNC + встроенный RFB/DistroDisplay
```

## Сборка в Termux

В каталоге проекта:

```bash
chmod +x tools/doctor.sh tools/bootstrap-libtermux.sh gradlew
./tools/doctor.sh
./tools/bootstrap-libtermux.sh
./gradlew :app:assembleDebug
```

Готовый APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

На первом запуске Android-приложение загружает rootfs выбранного Linux. Для текущей APK-конфигурации используется ARM64 bootstrap. Root не требуется: OS module работает в режиме PRoot.

## Android Studio

Открывайте корень проекта после выполнения `./tools/bootstrap-libtermux.sh`. Затем запустите `:app:assembleDebug` или обычную сборку APK.

## GitHub Actions

Workflow `.github/workflows/build-apk.yml` автоматически:

1. получает Legitiv;
2. получает исходники LibTermux;
3. собирает APK;
4. прикладывает `app-debug.apk` к workflow run.

## Фиксация версии LibTermux

По умолчанию используется ветка `main`. Для воспроизводимой сборки задайте commit/tag:

```bash
LIBTERMUX_REF=<commit-or-tag> ./tools/bootstrap-libtermux.sh
```

## Ограничения

Upstream LibTermux прямо обозначает проект как экспериментальный. Поэтому текущий архив исправляет цепочку зависимостей и автоматизирует подключение исходников, но не является доказательством того, что все desktop/rootfs сценарии уже протестированы на конкретном HONOR/Android 16. Реальная сборка должна быть выполнена в среде с интернетом, Android SDK/Build Tools и JDK.

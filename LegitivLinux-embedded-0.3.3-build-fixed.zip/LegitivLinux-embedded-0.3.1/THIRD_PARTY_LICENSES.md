# Third-party licenses

## LibTermux

Project: https://github.com/libtermux/libtermux-android
License: Apache License 2.0

Legitiv does not bundle the LibTermux source in this archive. The build script downloads it from the upstream repository into `vendor/libtermux` before compilation.

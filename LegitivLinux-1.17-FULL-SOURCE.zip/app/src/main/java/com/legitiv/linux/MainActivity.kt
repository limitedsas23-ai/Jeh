package com.legitiv.linux

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.app.ActivityManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.libtermux.LibTermux
import com.libtermux.LogLevel
import com.libtermux.bootstrap.InstallState
import com.libtermux.bootstrap.NativeLibBootstrapProvider
import com.libtermux.os.createOs
import com.libtermux.os.distro.Distro
import com.libtermux.os.gui.DesktopSession
import com.libtermux.os.gui.compose.DistroDisplay
import com.libtermux.os.registry.DesktopEnvironment
import com.libtermux.os.registry.DisplayResolution
import com.libtermux.os.settings.DistroRuntimeSettings
import com.libtermux.view.TerminalView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.security.MessageDigest

private data class Profile(
    val id: String,
    val name: String,
    val distro: Distro,
    val description: String,
    val gui: Boolean,
    val packages: List<String>
)

private enum class AppTab(val label: String, val icon: ImageVector) {
    HOME("Linux", Icons.Default.PlayArrow),
    TERMINAL("Terminal", Icons.Default.Terminal),
    DESKTOP("Desktop", Icons.Default.Computer),
    PROGRAMS("Apps", Icons.Default.Computer),
    WINDOWS("Windows", Icons.Default.Computer),
    NETWORK("Network", Icons.Default.Security),
    SYSTEM("System", Icons.Default.Settings),
    OSINT("Async OSINT", Icons.Default.Security),
    SETTINGS("Настройки", Icons.Default.Settings),
}

private enum class UiTheme(
    val title: String,
    val primary: Color,
    val secondary: Color,
    val background: Color,
    val panel: Color,
) {
    NEON("Neon", Color(0xFF8B5CF6), Color(0xFF22D3EE), Color(0xFF080A12), Color(0xFF141729)),
    ORANGE("Orange", Color(0xFFFF8A00), Color(0xFFFFB347), Color(0xFF100B08), Color(0xFF21150E)),
    PEACH("Peach", Color(0xFFFF9B85), Color(0xFFFFC5A8), Color(0xFF110B0D), Color(0xFF241417)),
    ICE("Ice", Color(0xFF60A5FA), Color(0xFF67E8F9), Color(0xFF071018), Color(0xFF111D28)),
    MATRIX("Matrix", Color(0xFF39FF88), Color(0xFF16A34A), Color(0xFF040B07), Color(0xFF0C1711)),
    AMBER("Amber", Color(0xFFFFB000), Color(0xFFFFD166), Color(0xFF100D06), Color(0xFF211A0A)),
    VIOLET("Violet", Color(0xFFA78BFA), Color(0xFFF0ABFC), Color(0xFF0E0814), Color(0xFF1A1024)),
    CARBON("Carbon", Color(0xFFE5E7EB), Color(0xFF9CA3AF), Color(0xFF070707), Color(0xFF151515)),
}

private enum class LookupType(val label: String) {
    WEB("Web"), EMAIL("Email"), PHONE("Телефон"), DOMAIN("Домен"), IP("IP"), URL("URL")
}

private data class LookupResult(
    val title: String,
    val detail: String,
    val good: Boolean = true,
)


private data class LinuxAppSpec(
    val id: String,
    val title: String,
    val packageName: String,
    val launchCommand: String,
    val description: String,
    val note: String,
)

private enum class WindowsBackend(
    val title: String,
    val description: String,
    val defaultRunCommand: String,
    val defaultSteamCommand: String,
) {
    BOX64_WINE("Box64 + Wine", "x86_64 Windows через Box64 и Wine", "box64 wine64", "box64 steam"),
    FEX_WINE("FEX + Wine", "x86_64 через FEX; требуется x86-64 rootfs", "FEX wine64", "FEX steam"),
    PROTON("Proton bridge", "Экспериментальный профиль; требует отдельно установленного Proton/Wine runtime", "box64 wine64", "box64 steam"),
}

private enum class GraphicsProfile(val title: String, val description: String) {
    AUTO("Auto", "Выбирает доступный графический backend"),
    TURNIP("Turnip", "Для совместимых Adreno/Vulkan конфигураций"),
    VIRGL_ZINK("VirGL / Zink", "Mesa-совместимый путь через OpenGL/Vulkan"),
    SOFTWARE("Software", "CPU-рендеринг для диагностики; медленно для игр"),
}

private enum class Box64Preset(val title: String) {
    PERFORMANCE("Performance"),
    BALANCED("Balanced"),
    STABILITY("Stability"),
}

private data class CompatibilityCheck(
    val title: String,
    val detail: String,
    val good: Boolean,
    val required: Boolean = false,
)

private object UiStore {
    private const val PREFS = "legitiv_ui"
    private const val THEME = "theme"
    private const val PANEL_ALPHA = "panel_alpha"
    private const val DIM = "wallpaper_dim"
    private const val WALLPAPER = "wallpaper_uri"
    private const val BLUR = "wallpaper_blur"
    private const val IMMERSIVE = "immersive_linux"
    private const val KEEP_SCREEN = "keep_screen_on"
    private const val WIN_BACKEND = "win_backend"
    private const val WIN_RUN = "win_run_command"
    private const val WIN_STEAM = "win_steam_command"

    fun read(context: Context): MutableMap<String, Any> {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return mutableMapOf(
            THEME to (p.getString(THEME, UiTheme.NEON.name) ?: UiTheme.NEON.name),
            PANEL_ALPHA to p.getFloat(PANEL_ALPHA, 0.78f),
            DIM to p.getFloat(DIM, 0.45f),
            WALLPAPER to (p.getString(WALLPAPER, null) ?: ""),
            BLUR to p.getFloat(BLUR, 10f),
            IMMERSIVE to p.getBoolean(IMMERSIVE, true),
            KEEP_SCREEN to p.getBoolean(KEEP_SCREEN, true),
            WIN_BACKEND to (p.getString(WIN_BACKEND, WindowsBackend.BOX64_WINE.name) ?: WindowsBackend.BOX64_WINE.name),
            WIN_RUN to (p.getString(WIN_RUN, WindowsBackend.BOX64_WINE.defaultRunCommand) ?: WindowsBackend.BOX64_WINE.defaultRunCommand),
            WIN_STEAM to (p.getString(WIN_STEAM, WindowsBackend.BOX64_WINE.defaultSteamCommand) ?: WindowsBackend.BOX64_WINE.defaultSteamCommand),
        )
    }

    fun put(context: Context, key: String, value: Any?) {
        val e = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        when (value) {
            null -> e.remove(key)
            is String -> e.putString(key, value)
            is Float -> e.putFloat(key, value)
            is Int -> e.putInt(key, value)
            is Boolean -> e.putBoolean(key, value)
        }
        e.apply()
    }
}

private class AsyncLookupEngine(private val client: OkHttpClient = OkHttpClient()) {
    suspend fun run(type: LookupType, target: String): List<LookupResult> = coroutineScope {
        val q = target.trim()
        when (type) {
            LookupType.DOMAIN -> listOf("A", "AAAA", "MX", "NS", "TXT").map { rr ->
                async { dns(q, rr) }
            }.awaitAll()

            LookupType.IP -> listOf(async { rdap("ip", q) }).awaitAll()
            LookupType.URL -> listOf(async { head(q) }).awaitAll()
            LookupType.EMAIL, LookupType.PHONE, LookupType.WEB -> listOf(
                LookupResult(
                    "Публичный веб-поиск",
                    "Готово. Для Email/телефона Legitiv открывает обычный поисковик и не пытается устанавливать личность или получать закрытые данные."
                )
            )
        }
    }

    private suspend fun dns(name: String, type: String): LookupResult = withContext(Dispatchers.IO) {
        try {
            val url = "https://dns.google/resolve?name=${Uri.encode(name)}&type=$type"
            val body = get(url) ?: return@withContext LookupResult("DNS $type", "Нет ответа", false)
            val json = JSONObject(body)
            val answers = json.optJSONArray("Answer")
            if (answers == null || answers.length() == 0) {
                LookupResult("DNS $type", "Записей не найдено")
            } else {
                val values = buildList {
                    for (i in 0 until answers.length()) {
                        add(answers.getJSONObject(i).optString("data"))
                    }
                }.filter { it.isNotBlank() }
                LookupResult("DNS $type", values.joinToString("\n"))
            }
        } catch (t: Throwable) {
            LookupResult("DNS $type", t.message ?: "Ошибка запроса", false)
        }
    }

    private suspend fun rdap(kind: String, target: String): LookupResult = withContext(Dispatchers.IO) {
        try {
            val body = get("https://rdap.org/$kind/${Uri.encode(target)}")
                ?: return@withContext LookupResult("RDAP", "Нет ответа", false)
            val json = JSONObject(body)
            val title = json.optString("name").ifBlank { json.optString("handle").ifBlank { target } }
            val status = json.optJSONArray("status")?.let { arr ->
                (0 until arr.length()).joinToString(", ") { arr.optString(it) }
            } ?: "—"
            val country = json.optString("country").ifBlank { "—" }
            LookupResult("RDAP: $title", "status=$status\ncountry=$country")
        } catch (t: Throwable) {
            LookupResult("RDAP", t.message ?: "Ошибка запроса", false)
        }
    }

    private suspend fun head(target: String): LookupResult = withContext(Dispatchers.IO) {
        try {
            val url = if (target.startsWith("http://") || target.startsWith("https://")) target else "https://$target"
            val req = Request.Builder().url(url).head().build()
            client.newCall(req).execute().use { response ->
                LookupResult("HTTP", "${response.code} ${response.message}\n${response.header("content-type") ?: "content-type: —"}")
            }
        } catch (t: Throwable) {
            LookupResult("HTTP", t.message ?: "Ошибка запроса", false)
        }
    }

    private fun get(url: String): String? {
        val req = Request.Builder().url(url).get().build()
        return client.newCall(req).execute().use { response ->
            if (!response.isSuccessful) null else response.body?.string()
        }
    }
}

class MainActivity : ComponentActivity() {
    private val termux by lazy {
        LibTermux.init(applicationContext) {
            autoInstall = true
            logLevel = LogLevel.INFO
            backgroundExecutionEnabled = true
            bootstrapProvider = NativeLibBootstrapProvider.from(applicationContext)
            env("COLORTERM", "truecolor")
        }
    }

    private val os by lazy {
        termux.createOs {
            executionMode = com.libtermux.os.ExecutionMode.PROOT
            bindSdCard = true
            fakeRoot = true
            registry {
                distro(Distro.Ubuntu2404) {
                    guiEnabled = true
                    desktopEnvironment = DesktopEnvironment.XFCE4
                    defaultResolution = DisplayResolution.HD_720P
                    description = "Ubuntu 24.04 LTS + XFCE4"
                    extraPackages = listOf("git", "curl", "wget", "python3", "python3-pip", "vlc", "thunar")
                }
                distro(Distro.Debian12) {
                    guiEnabled = true
                    desktopEnvironment = DesktopEnvironment.XFCE4
                    defaultResolution = DisplayResolution.HD_720P
                    description = "Debian 12 Bookworm + XFCE4"
                    extraPackages = listOf("git", "curl", "wget", "python3", "python3-pip", "vlc", "thunar")
                }
                distro(Distro.Alpine) {
                    guiEnabled = true
                    desktopEnvironment = DesktopEnvironment.XFCE4
                    defaultResolution = DisplayResolution.SMALL_800P
                    description = "Минимальный Alpine Linux"
                    extraPackages = listOf("bash", "curl", "git", "python3")
                }
                distro(Distro.Kali) {
                    guiEnabled = true
                    desktopEnvironment = DesktopEnvironment.XFCE4
                    defaultResolution = DisplayResolution.HD_720P
                    description = "Kali Linux / NetHunter rootless-профиль"
                    extraPackages = listOf("git", "curl", "wget", "python3")
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LegitivApp() }
    }

    @Composable
    private fun LegitivApp() {
        val initial = remember { UiStore.read(this) }
        var themeId by rememberSaveable { mutableStateOf(initial["theme"] as String) }
        var panelAlpha by rememberSaveable { mutableFloatStateOf(initial["panel_alpha"] as Float) }
        var wallpaperDim by rememberSaveable { mutableFloatStateOf(initial["wallpaper_dim"] as Float) }
        var wallpaperUri by rememberSaveable { mutableStateOf(initial["wallpaper_uri"] as String) }
        var wallpaperBlur by rememberSaveable { mutableFloatStateOf(initial["wallpaper_blur"] as Float) }
        var immersiveLinux by rememberSaveable { mutableStateOf(initial["immersive_linux"] as Boolean) }
        var keepScreenOn by rememberSaveable { mutableStateOf(initial["keep_screen_on"] as Boolean) }
        var winBackendName by rememberSaveable { mutableStateOf(initial["win_backend"] as String) }
        var winRunCommand by rememberSaveable { mutableStateOf(initial["win_run_command"] as String) }
        var winSteamCommand by rememberSaveable { mutableStateOf(initial["win_steam_command"] as String) }
        var tab by rememberSaveable { mutableStateOf(AppTab.HOME.name) }
        var selected by rememberSaveable { mutableStateOf(Distro.Ubuntu2404.id) }
        var session by remember { mutableStateOf<DesktopSession?>(null) }
        var status by remember { mutableStateOf("Готово. Встроенный runtime ещё не инициализирован.") }
        var desktopLoading by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()
        val currentTheme = UiTheme.entries.firstOrNull { it.name == themeId } ?: UiTheme.NEON

        LaunchedEffect(immersiveLinux, keepScreenOn) {
            setImmersiveMode(immersiveLinux)
            if (keepScreenOn) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }

        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Throwable) {
                }
                wallpaperUri = uri.toString()
                UiStore.put(this, "wallpaper_uri", wallpaperUri)
            }
        }

        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = currentTheme.primary,
                secondary = currentTheme.secondary,
                background = currentTheme.background,
                surface = currentTheme.panel,
                onSurface = Color.White,
            )
        ) {
            var wallpaperBitmap by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
            LaunchedEffect(wallpaperUri) {
                wallpaperBitmap = null
                if (wallpaperUri.isNotBlank()) {
                    wallpaperBitmap = withContext(Dispatchers.IO) {
                        runCatching {
                            contentResolver.openInputStream(Uri.parse(wallpaperUri)).use { BitmapFactory.decodeStream(it) }
                                ?.asImageBitmap()
                        }.getOrNull()
                    }
                }
            }

            Box(Modifier.fillMaxSize()) {
                if (wallpaperBitmap != null) {
                    Image(
                        bitmap = wallpaperBitmap!!,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize().blur(wallpaperBlur.dp),
                        contentScale = ContentScale.Crop,
                    )
                } else {
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.linearGradient(listOf(currentTheme.background, currentTheme.panel, currentTheme.background))
                        )
                    )
                }
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = wallpaperDim.coerceIn(0f, 0.85f))))

                Row(Modifier.fillMaxSize().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Sidebar(
                        theme = currentTheme,
                        tab = AppTab.valueOf(tab),
                        onTab = { tab = it.name },
                        panelAlpha = panelAlpha,
                    )

                    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        TopBar(currentTheme, currentTheme.primary, status)
                        Surface(
                            modifier = Modifier.fillMaxSize(),
                            color = currentTheme.panel.copy(alpha = (panelAlpha * 0.72f).coerceIn(0.2f, 0.95f)),
                            shape = RoundedCornerShape(22.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.07f)),
                        ) {
                            val profiles = remember {
                                listOf(
                                    Profile("ubuntu", "Ubuntu 24.04", Distro.Ubuntu2404, "Полноценная Ubuntu-среда", true, listOf("git", "python3", "vlc", "thunar")),
                                    Profile("debian", "Debian 12", Distro.Debian12, "Стабильная Debian-среда", true, listOf("git", "python3", "vlc", "thunar")),
                                    Profile("alpine", "Alpine", Distro.Alpine, "Минимальная система", true, listOf("git", "python3")),
                                    Profile("kali", "Kali", Distro.Kali, "Rootless-профиль для лаборатории", true, listOf("git", "python3")),
                                )
                            }
                            val current = profiles.first { it.id == selected }

                            when (AppTab.valueOf(tab)) {
                                AppTab.HOME -> HomeScreen(
                                    theme = currentTheme,
                                    panelAlpha = panelAlpha,
                                    profiles = profiles,
                                    current = current,
                                    status = status,
                                    onSelect = { selected = it },
                                    onBootstrap = {
                                        scope.launch {
                                            termux.initialize().collect { s ->
                                                status = when (s) {
                                                    is InstallState.Checking -> "Проверка встроенного runtime…"
                                                    is InstallState.AlreadyInstalled -> "Runtime уже готов ✓"
                                                    is InstallState.Downloading -> "Подготовка bootstrap ${(s.progress * 100).toInt()}%"
                                                    is InstallState.Extracting -> "Распаковка runtime…"
                                                    is InstallState.Completed -> "Встроенный runtime готов ✓"
                                                    is InstallState.Failed -> "Ошибка: ${s.error}"
                                                    else -> "Инициализация…"
                                                }
                                            }
                                        }
                                    },
                                    onInstall = {
                                        scope.launch {
                                            if (!termux.isInstalled) {
                                                status = "Сначала инициализируйте встроенный runtime."
                                                return@launch
                                            }
                                            status = "Установка ${current.name}…"
                                            os.setupDistro(current.distro).collect { s -> status = s.toString() }
                                            status = "${current.name} готов."
                                        }
                                    },
                                    onDesktop = {
                                        scope.launch {
                                            try {
                                                if (!termux.isInstalled) {
                                                    status = "Сначала инициализируйте встроенный runtime."
                                                    return@launch
                                                }
                                                if (!os.isInstalled(current.distro)) {
                                                    status = "Сначала установите ${current.name}."
                                                    return@launch
                                                }
                                                desktopLoading = true
                                                val s = os.createDesktopSession(current.distro)
                                                val sd = os.registry[current.distro]!!
                                                s.start(
                                                    DistroRuntimeSettings(
                                                        distroId = current.distro.id,
                                                        displayWidth = sd.effectiveWidth,
                                                        displayHeight = sd.effectiveHeight,
                                                        colorDepth = sd.colorDepth,
                                                        vncPort = sd.vncPort,
                                                        vncPassword = sd.vncPassword ?: "",
                                                        showToolbar = true,
                                                        scaleToFit = true,
                                                    )
                                                )
                                                session = s
                                                tab = AppTab.DESKTOP.name
                                                status = "Запуск ${current.name} Desktop…"
                                            } catch (e: Exception) {
                                                status = "Desktop error: ${e.message}"
                                            } finally {
                                                desktopLoading = false
                                            }
                                        }
                                    },
                                    onOsint = { tab = AppTab.OSINT.name },
                                    onApps = { tab = AppTab.PROGRAMS.name },
                                    onWindows = { tab = AppTab.WINDOWS.name },
                                )

                                AppTab.TERMINAL -> TerminalScreen(termux)

                                AppTab.DESKTOP -> DesktopScreen(
                                    session = session,
                                    onClose = {
                                        scope.launch { session?.stop() }
                                        session = null
                                        tab = AppTab.HOME.name
                                    },
                                    loading = desktopLoading,
                                )

                                AppTab.PROGRAMS -> ProgramsScreen(
                                    theme = currentTheme,
                                    panelAlpha = panelAlpha,
                                    current = current,
                                    os = os,
                                    scope = scope,
                                    onStatus = { status = it },
                                )

                                AppTab.WINDOWS -> WindowsScreen(
                                    theme = currentTheme,
                                    panelAlpha = panelAlpha,
                                    distro = current.distro,
                                    os = os,
                                    backendName = winBackendName,
                                    runCommand = winRunCommand,
                                    steamCommand = winSteamCommand,
                                    onBackend = { b ->
                                        winBackendName = b.name
                                        winRunCommand = b.defaultRunCommand
                                        winSteamCommand = b.defaultSteamCommand
                                        UiStore.put(this, "win_backend", b.name)
                                        UiStore.put(this, "win_run_command", b.defaultRunCommand)
                                        UiStore.put(this, "win_steam_command", b.defaultSteamCommand)
                                    },
                                    onRunCommandChange = {
                                        winRunCommand = it
                                        UiStore.put(this, "win_run_command", it)
                                    },
                                    onSteamCommandChange = {
                                        winSteamCommand = it
                                        UiStore.put(this, "win_steam_command", it)
                                    },
                                    scope = scope,
                                    onStatus = { status = it },
                                )

                                AppTab.NETWORK -> NetworkScreen(
                                    theme = currentTheme,
                                    panelAlpha = panelAlpha,
                                    scope = scope,
                                )

                                AppTab.SYSTEM -> SystemScreen(
                                    theme = currentTheme,
                                    panelAlpha = panelAlpha,
                                    current = current,
                                )

                                AppTab.OSINT -> OsintScreen(
                                    theme = currentTheme,
                                    panelAlpha = panelAlpha,
                                    scope = scope,
                                )

                                AppTab.SETTINGS -> SettingsScreen(
                                    theme = currentTheme,
                                    themeId = themeId,
                                    panelAlpha = panelAlpha,
                                    wallpaperDim = wallpaperDim,
                                    wallpaperUri = wallpaperUri,
                                    wallpaperBlur = wallpaperBlur,
                                    immersiveLinux = immersiveLinux,
                                    keepScreenOn = keepScreenOn,
                                    onTheme = {
                                        themeId = it.name
                                        UiStore.put(this, "theme", it.name)
                                    },
                                    onPanelAlpha = {
                                        panelAlpha = it
                                        UiStore.put(this, "panel_alpha", it)
                                    },
                                    onWallpaperDim = {
                                        wallpaperDim = it
                                        UiStore.put(this, "wallpaper_dim", it)
                                    },
                                    onWallpaperBlur = {
                                        wallpaperBlur = it
                                        UiStore.put(this, "wallpaper_blur", it)
                                    },
                                    onImmersiveLinux = {
                                        immersiveLinux = it
                                        UiStore.put(this, "immersive_linux", it)
                                    },
                                    onKeepScreenOn = {
                                        keepScreenOn = it
                                        UiStore.put(this, "keep_screen_on", it)
                                    },
                                    onPickWallpaper = { launcher.launch(arrayOf("image/*")) },
                                    onClearWallpaper = {
                                        wallpaperUri = ""
                                        UiStore.put(this, "wallpaper_uri", "")
                                    },
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun Sidebar(theme: UiTheme, tab: AppTab, onTab: (AppTab) -> Unit, panelAlpha: Float) {
        Surface(
            modifier = Modifier.width(92.dp).fillMaxHeight(),
            color = theme.panel.copy(alpha = panelAlpha),
            shape = RoundedCornerShape(22.dp),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        ) {
            Column(
                Modifier.fillMaxSize().padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Box(
                    Modifier.size(50.dp).clip(RoundedCornerShape(16.dp)).background(
                        Brush.linearGradient(listOf(theme.primary, theme.secondary))
                    ),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("L", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.headlineSmall)
                }
                Spacer(Modifier.height(6.dp))
                AppTab.entries.forEach { item ->
                    val active = item == tab
                    Surface(
                        modifier = Modifier.fillMaxWidth().height(58.dp).clickable { onTab(item) },
                        color = if (active) theme.primary.copy(alpha = 0.20f) else Color.Transparent,
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Icon(item.icon, item.label, tint = if (active) theme.primary else Color.White.copy(alpha = 0.75f))
                            Text(item.label.take(10), style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = if (active) 1f else 0.65f))
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.Bolt, null, tint = theme.secondary)
                Text("v1.17", color = Color.White.copy(alpha = 0.55f), style = MaterialTheme.typography.labelSmall)
            }
        }
    }

    @Composable
    private fun TopBar(theme: UiTheme, accent: Color, status: String) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = theme.panel.copy(alpha = 0.82f),
            shape = RoundedCornerShape(22.dp),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("LEGITIV LINUX", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                    Text(status, color = Color.White.copy(alpha = 0.60f), maxLines = 1)
                }
                Surface(color = accent.copy(alpha = 0.14f), shape = CircleShape) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, null, tint = accent, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("ROOTLESS", color = accent, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }

    @Composable
    private fun HomeScreen(
        theme: UiTheme,
        panelAlpha: Float,
        profiles: List<Profile>,
        current: Profile,
        status: String,
        onSelect: (String) -> Unit,
        onBootstrap: () -> Unit,
        onInstall: () -> Unit,
        onDesktop: () -> Unit,
        onOsint: () -> Unit,
        onApps: () -> Unit,
        onWindows: () -> Unit,
    ) {
        LazyColumn(
            Modifier.fillMaxSize().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Legitiv — Linux. Desktop. Windows. OSINT.", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.height(5.dp))
                        Text("Единый Linux-first интерфейс: rootless Linux, встроенный Desktop, Linux-приложения, Windows-совместимость и Async-проверки публичных источников.", color = Color.White.copy(alpha = 0.68f))
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard(theme, panelAlpha, "4", "Linux-профиля", Modifier.weight(1f))
                    MetricCard(theme, panelAlpha, "VNC", "Desktop", Modifier.weight(1f))
                    MetricCard(theme, panelAlpha, "Apps", "GIMP / Blender / VLC", Modifier.weight(1f))
                    MetricCard(theme, panelAlpha, "Win", "Wine / Box64 / FEX", Modifier.weight(1f))
                    MetricCard(theme, panelAlpha, "Async", "Публичные проверки", Modifier.weight(1f))
                }
            }
            item {
                GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Дистрибутив", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            profiles.forEach { p ->
                                FilterChip(selected = current.id == p.id, onClick = { onSelect(p.id) }, label = { Text(p.name) })
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(current.description, color = Color.White.copy(alpha = 0.66f))
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    ActionButton(theme, "Runtime", "Инициализировать", Icons.Default.Refresh, Modifier.weight(1f), onBootstrap)
                    ActionButton(theme, "Linux", "Установить", Icons.Default.CloudDownload, Modifier.weight(1f), onInstall)
                    ActionButton(theme, "Desktop", "Запустить", Icons.Default.Computer, Modifier.weight(1f), onDesktop)
                    ActionButton(theme, "Apps", "Linux-приложения", Icons.Default.Computer, Modifier.weight(1f), onApps)
                    ActionButton(theme, "Windows", "Wine / Box64 / FEX", Icons.Default.Computer, Modifier.weight(1f), onWindows)
                }
            }
            item {
                GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Что уже внутри", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Text("• встроенный Termux bootstrap ARM64\n• PRoot без root\n• XFCE4 + VNC Desktop\n• стеклянный интерфейс + 8 тем\n• обои + blur + прозрачность\n• Linux Apps: GIMP, Blender, VLC, LibreOffice\n• Windows Hub: Box64 / FEX / Wine / Proton profiles\n• Async DNS / RDAP / HTTP / Web search\n• Network Lab и системная совместимость", color = Color.White.copy(alpha = 0.70f))
                    }
                }
            }
        }
    }

    @Composable
    private fun MetricCard(theme: UiTheme, alpha: Float, value: String, label: String, modifier: Modifier) {
        GlassCard(theme, alpha, modifier) {
            Column(Modifier.padding(14.dp)) {
                Text(value, color = theme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                Text(label, color = Color.White.copy(alpha = 0.58f), style = MaterialTheme.typography.labelMedium)
            }
        }
    }

    @Composable
    private fun ActionButton(theme: UiTheme, title: String, subtitle: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
        Surface(
            modifier = modifier.height(92.dp).clickable(onClick = onClick),
            color = theme.primary.copy(alpha = 0.10f),
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, theme.primary.copy(alpha = 0.20f)),
        ) {
            Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Icon(icon, null, tint = theme.primary)
                Column {
                    Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, color = Color.White.copy(alpha = 0.55f), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }

    @Composable
    private fun GlassCard(theme: UiTheme, alpha: Float, modifier: Modifier, content: @Composable ColumnScope.() -> Unit) {
        Card(
            modifier = modifier,
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = theme.panel.copy(alpha = alpha.coerceIn(0.25f, 1f))),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.07f)),
        ) { content() }
    }

    @Composable
    private fun TerminalScreen(termux: LibTermux) {
        Column(Modifier.fillMaxSize().background(Color(0xFF040404)).padding(4.dp)) {
            AndroidView(
                factory = { ctx ->
                    TerminalView(ctx).also { view ->
                        val s = termux.sessions.createSession("legitiv-main")
                        view.attachSession(s)
                        s.run("bash")
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }

    @Composable
    private fun DesktopScreen(session: DesktopSession?, onClose: () -> Unit, loading: Boolean) {
        Column(Modifier.fillMaxSize().background(Color.Black)) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onClose) { Text("← Legitiv") }
                Spacer(Modifier.width(8.dp))
                Text(session?.distro?.displayName ?: "Linux Desktop", color = Color.White)
            }
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                when {
                    loading -> CircularProgressIndicator()
                    session != null -> DistroDisplay(session = session, modifier = Modifier.fillMaxSize(), showToolbar = true, onClose = onClose)
                    else -> Text("Desktop ещё не запущен", color = Color.LightGray)
                }
            }
        }
    }

    @Composable
    private fun SystemScreen(
        theme: UiTheme,
        panelAlpha: Float,
        current: Profile,
    ) {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = remember { ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) } }
        val freeBytes = remember { Environment.getDataDirectory().freeSpace }
        val totalBytes = remember { Environment.getDataDirectory().totalSpace }
        val vulkan = remember { packageManager.hasSystemFeature(PackageManager.FEATURE_VULKAN_HARDWARE_LEVEL) }
        LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("System Center", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                    Text("Диагностика устройства и Linux-среды Legitiv.", color = Color.White.copy(alpha = 0.64f))
                }
            } }
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp)) {
                    val rows = listOf(
                        "ABI" to (Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"),
                        "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                        "CPU" to "${Runtime.getRuntime().availableProcessors()} logical cores",
                        "RAM" to "${memInfo.availMem / 1024 / 1024} MB free / ${memInfo.totalMem / 1024 / 1024} MB total",
                        "Storage" to "${freeBytes / 1024 / 1024 / 1024} GB free / ${totalBytes / 1024 / 1024 / 1024} GB total",
                        "Vulkan" to if (vulkan) "available" else "not reported",
                        "Linux profile" to current.name,
                    )
                    Text("Состояние", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(5.dp))
                    rows.forEach { (key, value) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Text(key, color = Color.White.copy(alpha = 0.56f), modifier = Modifier.width(110.dp))
                            Text(value, color = Color.White, modifier = Modifier.weight(1f))
                        }
                    }
                }
            } }
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp)) {
                    Text("Linux-only presentation", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(5.dp))
                    Text("Иммерсивный режим скрывает системные панели Android, но Android остаётся host OS. Для настоящей замены Android нужна отдельная прошивка/порт устройства.", color = Color.White.copy(alpha = 0.64f))
                }
            } }
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp)) {
                    Text("Экспорт диагностики", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = {
                        val report = buildString {
                            appendLine("Legitiv 1.17")
                            appendLine("ABI: ${Build.SUPPORTED_ABIS.firstOrNull()}")
                            appendLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                            appendLine("CPU: ${Runtime.getRuntime().availableProcessors()} cores")
                            appendLine("RAM: ${memInfo.totalMem / 1024 / 1024} MB")
                            appendLine("Storage free: ${freeBytes / 1024 / 1024 / 1024} GB")
                            appendLine("Vulkan: $vulkan")
                            appendLine("Linux profile: ${current.name}")
                        }
                        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, report)
                        }, "Отправить диагностику"))
                    }) {
                        Icon(Icons.Default.OpenInNew, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Поделиться")
                    }
                }
            } }
        }
    }

    @Composable
    private fun OsintScreen(theme: UiTheme, panelAlpha: Float, scope: kotlinx.coroutines.CoroutineScope) {
        var typeName by rememberSaveable { mutableStateOf(LookupType.WEB.name) }
        var target by rememberSaveable { mutableStateOf("") }
        var running by remember { mutableStateOf(false) }
        var results by remember { mutableStateOf<List<LookupResult>>(emptyList()) }
        val type = LookupType.valueOf(typeName)
        val engine = remember { AsyncLookupEngine() }

        val doSearch: () -> Unit = {
            val value = target.trim()
            if (value.isNotBlank()) {
                running = true
                scope.launch {
                    results = engine.run(type, value)
                    running = false
                }
            }
        }

        LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = theme.primary.copy(alpha = 0.16f), shape = CircleShape) {
                                Icon(Icons.Default.Security, null, tint = theme.primary, modifier = Modifier.padding(10.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Async OSINT", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                                Text("Публичные источники и безопасные сетевые проверки", color = Color.White.copy(alpha = 0.62f))
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("Модуль работает только с открытыми источниками: DNS, RDAP, HTTP и обычный веб-поиск. Для Email/телефона он не извлекает закрытые сведения и не устанавливает личность человека.", color = Color.White.copy(alpha = 0.68f))
                    }
                }
            }
            item {
                GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            LookupType.entries.forEach { t ->
                                FilterChip(selected = type == t, onClick = { typeName = t.name }, label = { Text(t.label) })
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = target,
                            onValueChange = { target = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Цель") },
                            placeholder = { Text("example.com / 1.2.3.4 / email / телефон") },
                            singleLine = true,
                            trailingIcon = {
                                if (target.isNotBlank()) IconButton(onClick = { target = "" }) { Icon(Icons.Default.Clear, null) }
                            }
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(enabled = target.isNotBlank() && !running, onClick = doSearch) {
                                if (running) CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                else Icon(Icons.Default.Bolt, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Запустить Async")
                            }
                            OutlinedButton(onClick = {
                                val encoded = URLEncoder.encode(target.trim(), "UTF-8")
                                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$encoded")))
                            }, enabled = target.isNotBlank()) {
                                Icon(Icons.Default.OpenInNew, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Web-поиск")
                            }
                        }
                    }
                }
            }
            items(results) { item ->
                GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(15.dp)) {
                        Text(item.title, color = if (item.good) theme.primary else Color(0xFFFF7B72), fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(5.dp))
                        Text(item.detail, color = Color.White.copy(alpha = 0.70f))
                    }
                }
            }
            item {
                GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("OpenOSINT runtime", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("OpenOSINT можно установить внутрь Ubuntu и запускать его CLI из Legitiv. Проект заявляет 20 OSINT-инструментов и MIT-лицензию.", color = Color.White.copy(alpha = 0.62f))
                        Spacer(Modifier.height(7.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            OutlinedButton(onClick = {
                                scope.launch {
                                    if (!termux.isInstalled || !os.isInstalled(Distro.Ubuntu2404)) {
                                        onStatus("Сначала установите Ubuntu 24.04 в Linux-профиле.")
                                    } else {
                                        val ok = os.hasBinary(Distro.Ubuntu2404, "openosint")
                                        onStatus(if (ok) "OpenOSINT найден." else "OpenOSINT не найден.")
                                    }
                                }
                            }) { Text("Проверить") }
                            Button(onClick = {
                                scope.launch {
                                    if (!termux.isInstalled || !os.isInstalled(Distro.Ubuntu2404)) {
                                        onStatus("Сначала установите Ubuntu 24.04.")
                                        return@launch
                                    }
                                    val r = os.execute(Distro.Ubuntu2404, "python3 -m pip install --user -U openosint 2>&1 || pip3 install -U openosint 2>&1")
                                    onStatus(if (r.exitCode == 0) "OpenOSINT установлен." else "OpenOSINT: ${r.stderr.ifBlank { r.stdout.takeLast(220) }}")
                                }
                            }) { Text("Install") }
                            OutlinedButton(onClick = {
                                scope.launch {
                                    if (!termux.isInstalled || !os.isInstalled(Distro.Ubuntu2404)) { onStatus("Сначала установите Ubuntu 24.04."); return@launch }
                                    os.execute(Distro.Ubuntu2404, "nohup openosint >/tmp/legitiv-openosint.log 2>&1 &")
                                    onStatus("OpenOSINT запущен; лог /tmp/legitiv-openosint.log")
                                }
                            }) { Text("Launch") }
                        }
                    }
                }
            }
            item {
                GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(15.dp)) {
                        Text("OpenOSINT", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Для расширенного локального OSINT можно подключить OpenOSINT через встроенный Linux/Termux отдельно. Лицензия MIT; проект заявляет использование для authorized security research.", color = Color.White.copy(alpha = 0.66f))
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/OpenOSINT/OpenOSINT")))
                        }) {
                            Text("Открыть официальный OpenOSINT")
                        }
                    }
                }
            }
        }
    }

    private fun setImmersiveMode(enabled: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                if (enabled) {
                    controller.hide(android.view.WindowInsets.Type.systemBars())
                    controller.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                } else {
                    controller.show(android.view.WindowInsets.Type.systemBars())
                }
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (enabled) {
                (android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                    or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
            } else 0
        }
    }

    @Composable
    private fun ProgramsScreen(
        theme: UiTheme,
        panelAlpha: Float,
        current: Profile,
        os: com.libtermux.os.OsEnvironment,
        scope: kotlinx.coroutines.CoroutineScope,
        onStatus: (String) -> Unit,
    ) {
        val apps = remember {
            listOf(
                LinuxAppSpec("gimp", "GIMP", "gimp", "gimp", "Редактор изображений", "ARM64-пакет Ubuntu/Debian; нужен GUI Desktop"),
                LinuxAppSpec("blender", "Blender", "blender", "blender", "3D и рендеринг", "Тяжёлая нагрузка; графический ускоритель может влиять на скорость"),
                LinuxAppSpec("vlc", "VLC", "vlc", "vlc", "Медиаплеер", "GUI Desktop"),
                LinuxAppSpec("libreoffice", "LibreOffice", "libreoffice", "libreoffice", "Офисный пакет", "Большой пакет; устанавливается по запросу"),
                LinuxAppSpec("thunar", "Thunar", "thunar", "thunar", "Файловый менеджер XFCE", "Лёгкий вариант для Desktop"),
            )
        }
        LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) {
                Text("Linux Apps", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                Text("Устанавливайте ARM64 Linux-приложения внутрь выбранного дистрибутива и запускайте их из Desktop.", color = Color.White.copy(alpha = 0.64f))
                Spacer(Modifier.height(8.dp)); Text("Профиль: ${current.name}", color = theme.secondary)
            } } }
            items(apps) { app ->
                GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) { Column(Modifier.padding(15.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = theme.primary.copy(alpha = 0.15f), shape = CircleShape) { Text(app.title.take(1), color = theme.primary, modifier = Modifier.padding(10.dp), fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) {
                            Text(app.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text(app.description, color = Color.White.copy(alpha = 0.62f))
                            Text(app.note, color = Color.White.copy(alpha = 0.46f), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            scope.launch {
                                if (!termux.isInstalled) { onStatus("Сначала инициализируйте runtime."); return@launch }
                                if (!os.isInstalled(current.distro)) { onStatus("Сначала установите ${current.name}."); return@launch }
                                onStatus("Проверка ${app.title}…")
                                val exists = os.hasBinary(current.distro, app.packageName)
                                onStatus(if (exists) "${app.title}: уже установлен ✓" else "${app.title}: требуется установка")
                            }
                        }) { Text("Проверить") }
                        OutlinedButton(onClick = {
                            scope.launch {
                                if (!termux.isInstalled || !os.isInstalled(current.distro)) { onStatus("Нужен установленный ${current.name}."); return@launch }
                                onStatus("Установка ${app.title}…")
                                val result = os.install(current.distro, app.packageName)
                                onStatus("${app.title}: ${result.stdout.takeLast(240).ifBlank { result.stderr.takeLast(240) }}")
                            }
                        }) { Text("Установить") }
                        OutlinedButton(onClick = {
                            scope.launch {
                                if (!termux.isInstalled || !os.isInstalled(current.distro)) { onStatus("Нужен установленный ${current.name}."); return@launch }
                                val cmd = "DISPLAY=:1 nohup ${app.launchCommand} >/tmp/legitiv-${app.id}.log 2>&1 &"
                                os.execute(current.distro, cmd)
                                onStatus("Запуск ${app.title} отправлен в Desktop")
                            }
                        }) { Text("Запустить") }
                    }
                } }
            }
        }
    }

    private fun compatibilityChecks(context: Context): List<CompatibilityCheck> {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo().also(am::getMemoryInfo)
        val ramGb = mem.totalMem / 1_000_000_000.0
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        val vulkan = context.packageManager.hasSystemFeature("android.hardware.vulkan.version") ||
            context.packageManager.hasSystemFeature(PackageManager.FEATURE_VULKAN_HARDWARE_LEVEL)
        val freeGb = context.dataDir.usableSpace / 1_000_000_000.0
        return listOf(
            CompatibilityCheck("ABI", abi, abi == "arm64-v8a", true),
            CompatibilityCheck("Android", "API ${Build.VERSION.SDK_INT}", Build.VERSION.SDK_INT >= 26, true),
            CompatibilityCheck("ОЗУ", String.format(java.util.Locale.US, "%.1f GB", ramGb), ramGb >= 4.0, false),
            CompatibilityCheck("Vulkan", if (vulkan) "hardware feature доступен" else "hardware feature не обнаружен", vulkan, false),
            CompatibilityCheck("Свободное место", String.format(java.util.Locale.US, "%.1f GB", freeGb), freeGb >= 6.0, false),
        )
    }

    @Composable
    private fun WindowsScreen(
        theme: UiTheme,
        panelAlpha: Float,
        distro: Distro,
        os: com.libtermux.os.OsEnvironment,
        backendName: String,
        runCommand: String,
        steamCommand: String,
        onBackend: (WindowsBackend) -> Unit,
        onRunCommandChange: (String) -> Unit,
        onSteamCommandChange: (String) -> Unit,
        scope: kotlinx.coroutines.CoroutineScope,
        onStatus: (String) -> Unit,
    ) {
        val backend = WindowsBackend.entries.firstOrNull { it.name == backendName } ?: WindowsBackend.BOX64_WINE
        var exePath by rememberSaveable { mutableStateOf("") }
        var runtimeChecks by remember { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
        val checks = remember { compatibilityChecks(this@MainActivity) }
        var profileName by rememberSaveable { mutableStateOf("Default") }
        var winePrefix by rememberSaveable { mutableStateOf("/root/.legitiv/prefixes/default") }
        var launchArgs by rememberSaveable { mutableStateOf("") }
        var envVars by rememberSaveable { mutableStateOf("") }
        var graphicsName by rememberSaveable { mutableStateOf(GraphicsProfile.AUTO.name) }
        var box64Name by rememberSaveable { mutableStateOf(Box64Preset.BALANCED.name) }
        var dxvk by rememberSaveable { mutableStateOf(true) }
        var vkd3d by rememberSaveable { mutableStateOf(false) }
        LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) {
                Text("Windows Hub", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                Text("Winlator-подобная оболочка: проверка устройства, выбор backend и запуск пользовательских Windows/Linux x86 программ.", color = Color.White.copy(alpha = 0.64f))
                Spacer(Modifier.height(8.dp)); Text("Текущий backend: ${backend.title}", color = theme.secondary)
            } } }
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) { Column(Modifier.padding(15.dp)) {
                Text("Совместимость устройства", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                checks.forEach { c ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, null, tint = if (c.good) theme.primary else Color(0xFFFF7B72), modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(7.dp)); Column(Modifier.weight(1f)) {
                            Text(c.title, color = Color.White, fontWeight = FontWeight.Medium)
                            Text(c.detail, color = Color.White.copy(alpha = 0.58f), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Text("Проверка является аппаратным preflight, а не гарантией запуска конкретной игры.", color = Color.White.copy(alpha = 0.46f), style = MaterialTheme.typography.labelSmall)
            } } }
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) { Column(Modifier.padding(15.dp)) {
                Text("Backend", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                    WindowsBackend.entries.forEach { b -> FilterChip(selected = b == backend, onClick = { onBackend(b) }, label = { Text(b.title) }) }
                }
                Spacer(Modifier.height(8.dp)); Text(backend.description, color = Color.White.copy(alpha = 0.62f))
                Text("Архитектура Winlator-подобной цепочки: ARM64 → x86-64 translation → Wine/Proton → DXVK/Vulkan.", color = Color.White.copy(alpha = 0.48f), style = MaterialTheme.typography.labelSmall)
            } } }
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) { Column(Modifier.padding(15.dp)) {
                Text("Game profile", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Профиль в стиле Winlator: отдельный WINEPREFIX, renderer, Box64 preset, DXVK/VKD3D и аргументы запуска.", color = Color.White.copy(alpha = 0.62f))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = profileName, onValueChange = { profileName = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Имя профиля") }, singleLine = true)
                Spacer(Modifier.height(7.dp))
                OutlinedTextField(value = winePrefix, onValueChange = { winePrefix = it }, modifier = Modifier.fillMaxWidth(), label = { Text("WINEPREFIX") }, singleLine = true)
                Spacer(Modifier.height(7.dp))
                Text("Graphics", color = Color.White.copy(alpha = 0.70f), style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    GraphicsProfile.entries.forEach { g -> FilterChip(selected = graphicsName == g.name, onClick = { graphicsName = g.name }, label = { Text(g.title) }) }
                }
                Spacer(Modifier.height(5.dp))
                Text("Box64", color = Color.White.copy(alpha = 0.70f), style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    Box64Preset.entries.forEach { b -> FilterChip(selected = box64Name == b.name, onClick = { box64Name = b.name }, label = { Text(b.title) }) }
                }
                Spacer(Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = dxvk, onCheckedChange = { dxvk = it }); Text("DXVK", color = Color.White)
                    Spacer(Modifier.width(8.dp)); Checkbox(checked = vkd3d, onCheckedChange = { vkd3d = it }); Text("VKD3D", color = Color.White)
                }
                OutlinedTextField(value = launchArgs, onValueChange = { launchArgs = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Launch arguments") }, singleLine = true)
                Spacer(Modifier.height(7.dp))
                OutlinedTextField(value = envVars, onValueChange = { envVars = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Environment KEY=VALUE KEY2=VALUE2") }, singleLine = true)
                Spacer(Modifier.height(7.dp))
                Text("${profileName.ifBlank { "Default" }} • ${GraphicsProfile.valueOf(graphicsName).title} • ${Box64Preset.valueOf(box64Name).title} • DXVK=${if (dxvk) "on" else "off"}", color = theme.secondary, style = MaterialTheme.typography.labelSmall)
                Text("${GraphicsProfile.valueOf(graphicsName).description}; конкретный runtime должен быть установлен отдельно.", color = Color.White.copy(alpha = 0.48f), style = MaterialTheme.typography.labelSmall)
            } } }
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) { Column(Modifier.padding(15.dp)) {
                Text("Runtime detection", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                runtimeChecks.forEach { (name, ok) -> Text("${if (ok) "✓" else "✕"} $name", color = if (ok) theme.primary else Color(0xFFFF7B72)) }
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    scope.launch {
                        if (!termux.isInstalled || !os.isInstalled(distro)) { onStatus("Установите ${distro.displayName} перед проверкой runtime."); return@launch }
                        val names = listOf("box64", "box86", "FEX", "wine", "wine64", "steam", "proton")
                        val map = linkedMapOf<String, Boolean>()
                        names.forEach { n -> map[n] = os.hasBinary(distro, n) }
                        runtimeChecks = map
                        onStatus("Windows runtime проверен")
                    }
                }) { Text("Проверить runtime") }
            } } }
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) { Column(Modifier.padding(15.dp)) {
                Text("Windows / EXE", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = exePath, onValueChange = { exePath = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Путь к EXE внутри Linux") }, placeholder = { Text("/sdcard/Download/game.exe") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = runCommand, onValueChange = onRunCommandChange, modifier = Modifier.fillMaxWidth(), label = { Text("Runtime command") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                Button(enabled = exePath.isNotBlank(), onClick = {
                    scope.launch {
                        if (!termux.isInstalled || !os.isInstalled(distro)) { onStatus("Нужен установленный ${distro.displayName}."); return@launch }
                        val q = shellQuote(exePath)
                        val prefix = shellQuote(winePrefix.ifBlank { "/root/.legitiv/prefixes/default" })
                        val env = envVars.trim().split(Regex("\\s+")).filter { it.contains("=") }.joinToString(" ")
                        val runtime = listOf(env, "WINEPREFIX=$prefix", runCommand, q, launchArgs.trim()).filter { it.isNotBlank() }.joinToString(" ")
                        val command = "mkdir -p $prefix && nohup $runtime >/tmp/legitiv-windows.log 2>&1 &"
                        os.execute(distro, command)
                        onStatus("EXE запущен через ${backend.title}; профиль=${profileName.ifBlank { "Default" }}")
                    }
                }) { Text("Запустить EXE") }
            } } }
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) { Column(Modifier.padding(15.dp)) {
                Text("Steam", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = steamCommand, onValueChange = onSteamCommandChange, modifier = Modifier.fillMaxWidth(), label = { Text("Steam command") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    scope.launch {
                        if (!termux.isInstalled || !os.isInstalled(distro)) { onStatus("Нужен установленный ${distro.displayName}."); return@launch }
                        os.execute(distro, "nohup $steamCommand >/tmp/legitiv-steam.log 2>&1 &")
                        onStatus("Steam launch отправлен в ${distro.displayName}")
                    }
                }) { Text("Запустить Steam") }
                Spacer(Modifier.height(6.dp))
                Text("Steam/игры не поставляются в APK. Legitiv предоставляет контейнерную точку запуска и проверяет runtime; конкретная совместимость зависит от Wine/Proton, Box64/FEX, GPU driver и самой игры.", color = Color.White.copy(alpha = 0.54f), style = MaterialTheme.typography.labelSmall)
            } } }
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) { Column(Modifier.padding(15.dp)) {
                Text("Официальные проекты", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(7.dp))
                OutlinedButton(onClick = { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/winebox64/winlator"))) }) { Text("Winlator WB64") }
                Spacer(Modifier.height(4.dp))
                OutlinedButton(onClick = { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/ptitSeb/box64"))) }) { Text("Box64") }
                Spacer(Modifier.height(4.dp))
                OutlinedButton(onClick = { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/FEX-Emu/FEX"))) }) { Text("FEX") }
            } } }
        }
    }

    private fun shellQuote(value: String): String = "'" + value.replace("'", "'\\''") + "'"

    @Composable
    private fun NetworkScreen(
        theme: UiTheme,
        panelAlpha: Float,
        scope: kotlinx.coroutines.CoroutineScope,
    ) {
        var networkText by remember { mutableStateOf("Нажмите «Проверить сеть».") }
        var dnsText by remember { mutableStateOf("—") }
        val connectivity = remember { getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager }
        LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) {
                Text("Network Lab", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                Text("Диагностика собственной сети без перехвата трафика и без попыток извлечь чужие Wi-Fi пароли.", color = Color.White.copy(alpha = 0.64f))
            } } }
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) { Column(Modifier.padding(15.dp)) {
                Text("Активное соединение", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(networkText, color = Color.White.copy(alpha = 0.72f))
                Spacer(Modifier.height(6.dp))
                Text("DNS: $dnsText", color = Color.White.copy(alpha = 0.58f))
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    scope.launch(Dispatchers.IO) {
                        val net = connectivity.activeNetwork
                        val caps = net?.let { connectivity.getNetworkCapabilities(it) }
                        val props = net?.let { connectivity.getLinkProperties(it) }
                        val transports = buildList {
                            if (caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true) add("Wi-Fi")
                            if (caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) == true) add("Mobile")
                            if (caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET) == true) add("Ethernet")
                            if (caps?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_VPN) == true) add("VPN")
                        }.ifEmpty { listOf("Unknown") }
                        val dns = props?.dnsServers?.joinToString { it.hostAddress ?: "?" }.orEmpty().ifBlank { "—" }
                        withContext(Dispatchers.Main) {
                            networkText = "Transport: ${transports.joinToString()}\nValidated: ${caps?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true}\nMetered: ${caps?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_METERED) != true}"
                            dnsText = dns
                        }
                    }
                }) { Text("Проверить сеть") }
            } } }
            item { GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) { Column(Modifier.padding(15.dp)) {
                Text("Wi-Fi security note", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Android не предоставляет обычному стороннему приложению универсальный доступ к сохранённым Wi-Fi паролям. Здесь Legitiv делает диагностику сети и показывает рекомендации по WPA2/WPA3, WPS и обновлению роутера.", color = Color.White.copy(alpha = 0.58f))
            } } }
        }
    }

        }
            }
        }
    }

    @Composable
    private fun SettingsScreen(
        theme: UiTheme,
        themeId: String,
        panelAlpha: Float,
        wallpaperDim: Float,
        wallpaperUri: String,
        wallpaperBlur: Float,
        immersiveLinux: Boolean,
        keepScreenOn: Boolean,
        onTheme: (UiTheme) -> Unit,
        onPanelAlpha: (Float) -> Unit,
        onWallpaperDim: (Float) -> Unit,
        onWallpaperBlur: (Float) -> Unit,
        onImmersiveLinux: (Boolean) -> Unit,
        onKeepScreenOn: (Boolean) -> Unit,
        onPickWallpaper: () -> Unit,
        onClearWallpaper: () -> Unit,
    ) {
        LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Настройки интерфейса", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                        Text("Прозрачность, стеклянные панели, темы и обои сохраняются на устройстве.", color = Color.White.copy(alpha = 0.60f))
                    }
                }
            }
            item {
                GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Palette, null, tint = theme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("Тема", color = Color.White, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            UiTheme.entries.forEach { t ->
                                FilterChip(selected = themeId == t.name, onClick = { onTheme(t) }, label = { Text(t.title) })
                            }
                        }
                    }
                }
            }
            item {
                GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Прозрачность панелей: ${(panelAlpha * 100).toInt()}%", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Slider(value = panelAlpha, onValueChange = onPanelAlpha, valueRange = 0.35f..1f)
                        Text("Затемнение обоев: ${(wallpaperDim * 100).toInt()}%", color = Color.White.copy(alpha = 0.65f))
                        Slider(value = wallpaperDim, onValueChange = onWallpaperDim, valueRange = 0f..0.85f)
                        Text("Размытие обоев: ${wallpaperBlur.toInt()} dp", color = Color.White.copy(alpha = 0.65f))
                        Slider(value = wallpaperBlur, onValueChange = onWallpaperBlur, valueRange = 0f..30f)
                    }
                }
            }
            item {
                GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DarkMode, null, tint = theme.secondary)
                            Spacer(Modifier.width(8.dp))
                            Text("Обои", color = Color.White, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(if (wallpaperUri.isBlank()) "Сейчас используется встроенный градиент." else "Пользовательские обои установлены." , color = Color.White.copy(alpha = 0.62f))
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = onPickWallpaper) { Text("Выбрать обои") }
                            if (wallpaperUri.isNotBlank()) {
                                OutlinedButton(onClick = onClearWallpaper) {
                                    Icon(Icons.Default.Delete, null)
                                    Spacer(Modifier.width(5.dp))
                                    Text("Убрать")
                                }
                            }
                        }
                    }
                }
            }
            item {
                GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Linux shell mode", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Иммерсивный режим", color = Color.White)
                                Text("Скрывать системные панели Android во время Linux-сессии", color = Color.White.copy(alpha = 0.60f))
                            }
                            Switch(checked = immersiveLinux, onCheckedChange = onImmersiveLinux)
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Не выключать экран", color = Color.White)
                                Text("Удобно для долгих Desktop / Steam-сессий", color = Color.White.copy(alpha = 0.60f))
                            }
                            Switch(checked = keepScreenOn, onCheckedChange = onKeepScreenOn)
                        }
                    }
                }
            }
            item {
                GlassCard(theme, panelAlpha, Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Архитектура", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Android 26+ • ARM64 bootstrap • PRoot • TigerVNC/RFB • root не требуется", color = Color.White.copy(alpha = 0.62f))
                        Spacer(Modifier.height(8.dp))
                        Text("Конфиденциальность: сетевые проверки запускаются только после действия пользователя. Для Email и телефона используется обычный публичный поиск.", color = Color.White.copy(alpha = 0.62f))
                    }
                }
            }
        }
    }
}

# Legitiv 1.17

## Цель
Legitiv 1.17 — Linux-first Android shell: встроенный ARM64 rootless Linux, Desktop/VNC, Linux Apps, Windows compatibility hub, Network Lab, Async OSINT и расширенная кастомизация.

## Windows compatibility
Архитектура сделана как модуль совместимости, а не как обещание запуска любой Windows-игры. На ARM64 Windows x86-64 требует дополнительного слоя CPU translation (например, Box64 или FEX) и x86-64 Wine/Proton; графический стек (Vulkan/DXVK/драйвер) зависит от устройства. Официальный Winlator использует Wine + Box86/Box64 и графические компоненты Mesa/DXVK/VKD3D; Box64 официально поддерживает Wine/Proton и запускает x86-64 Linux-программы на ARM64 Linux.

## Комплект
- Ubuntu 24.04 / Debian 12 / Alpine / Kali профили
- XFCE4 + VNC desktop
- GIMP / Blender / VLC / LibreOffice / Thunar launcher
- Windows Hub: Box64+Wine, FEX+Wine, Proton profiles
- Steam command profile
- device compatibility preflight (ABI, Android API, RAM, Vulkan feature, storage)
- Network Lab
- Async DNS/RDAP/HTTP/Web checks
- glass UI: 8 themes, transparency, wallpaper, blur, immersive mode, keep-screen-on

## Сборка
Требования для текущего Gradle/AGP стека: JDK 17, Gradle 9.4.1, Android SDK 36. У AGP 9.2 минимум Gradle 9.4.1 и JDK 17.

```bash
./gradlew --no-daemon --stacktrace :app:assembleDebug
```

APK:
`app/build/outputs/apk/debug/app-debug.apk`

Перед сборкой на Linux можно выполнить:
```bash
./tools/verify-release.sh
```

## Лицензии
Не встраивайте Windows игры, Steam или проприетарные runtime-файлы в APK без соответствующих прав. Legitiv хранит команды/профили и запускает пользовательские runtime-компоненты, когда они установлены в Linux-среде.

# Legitiv 1.17 — полный исходный проект

Это полный Android/Gradle-исходник Legitiv 1.17.

В корне должны находиться:
- `app/` — Android-модуль и Kotlin-код приложения;
- `gradle/` — настройки Gradle Wrapper;
- `.github/workflows/` — GitHub Actions;
- `tools/` — подготовка LibTermux и проверки;
- `termux/` — вспомогательные скрипты;
- `settings.gradle.kts`, `build.gradle.kts`, `gradlew` и `gradle.properties`.

Передача проекта не означает, что APK уже был успешно собран в этом окружении: для LibTermux используется отдельная загрузка исходников на этапе подготовки/CI.

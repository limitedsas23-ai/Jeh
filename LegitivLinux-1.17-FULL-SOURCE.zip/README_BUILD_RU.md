# Legitiv 1.17 — сборка

Legitiv 1.17 — Android-приложение с rootless Linux, встроенным Desktop, Linux Apps, Windows Hub, Network Lab, Async OSINT и стеклянной кастомизацией.

## CachyOS / Arch Linux

Установите базовые инструменты:

```bash
sudo pacman -Syu
sudo pacman -S --needed git unzip curl ca-certificates dpkg jdk17-openjdk
```

Проверьте Java:

```bash
java -version
```

Должна использоваться Java 17.

Запустите сборку одним скриптом:

```bash
chmod +x tools/build-linux.sh
./tools/build-linux.sh
```

Скрипт при необходимости сам скачает Gradle 9.4.1, подготовит и пропатчит LibTermux, выполнит compatibility gate и соберёт APK.

Результат:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Android Studio

Открывайте корень `LegitivLinux-1.17`. В **Settings → Build Tools → Gradle** используйте Gradle Wrapper/локальную Gradle 9.4.1 и JDK 17. Если Android Studio показывает старый wrapper 9.3.0, откройте `gradle/wrapper/gradle-wrapper.properties` и выставьте:

```properties
distributionUrl=https\://services.gradle.org/distributions/gradle-9.4.1-bin.zip
```

В текущем исходном архиве CI не зависит от отсутствующего `gradle-wrapper.jar`: GitHub Actions устанавливает Gradle 9.4.1 через `gradle/actions/setup-gradle@v6` и запускает `gradle` напрямую.

## Compatibility gate

Перед сборкой выполняются проверки:

- версия приложения 1.17;
- compile/target SDK 36;
- JDK/Gradle configuration;
- shell scripts (`bash -n`);
- наличие и патчи LibTermux;
- ключевые UI/Windows/OSINT-маркеры;
- после сборки — наличие APK, package name, SDK/target SDK и SHA-256.

Аппаратная совместимость Windows/Steam проверяется уже на телефоне внутри Windows Hub. Аппаратная проверка не гарантирует совместимость конкретной игры.

## Linux Desktop и Windows Hub

Linux Desktop работает как графическая сессия внутри Android-host. Иммерсивный режим скрывает системные панели Android, но сам Android остаётся host OS.

Windows Hub проектируется по той же схеме, которую используют Winlator-подобные решения: ARM64 host → Box64/FEX → x86_64 Wine/Proton → DXVK/VKD3D/Vulkan. В APK не встраиваются Steam/Windows-игры или проприетарные runtime-файлы. Они должны быть предоставлены пользователем или собраны/установлены из совместимых источников.

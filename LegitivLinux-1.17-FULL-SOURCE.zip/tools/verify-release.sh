#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
cd "$ROOT"

fail(){ echo "[Legitiv VERIFY] FAIL: $*" >&2; exit 1; }
pass(){ echo "[Legitiv VERIFY] OK: $*"; }

test -f app/build.gradle.kts || fail "app/build.gradle.kts missing"
test -f gradle/wrapper/gradle-wrapper.properties || fail "gradle wrapper properties missing"
grep -q 'versionCode = 117' app/build.gradle.kts || fail "versionCode is not 117"
grep -q 'versionName = "1.17"' app/build.gradle.kts || fail "versionName is not 1.17"
grep -q 'gradle-9.4.1-bin.zip' gradle/wrapper/gradle-wrapper.properties || fail "Gradle wrapper is not 9.4.1"
grep -q 'compileSdk = 36' app/build.gradle.kts || fail "compileSdk 36 missing"
grep -q 'targetSdk = 36' app/build.gradle.kts || fail "targetSdk 36 missing"
grep -q 'applicationId = "com.legitiv.linux"' app/build.gradle.kts || fail "application id changed"
grep -q 'android:label="Legitiv"' app/src/main/AndroidManifest.xml || fail "app label is not Legitiv"
MAIN="app/src/main/java/com/legitiv/linux/MainActivity.kt"
test -f "$MAIN" || fail "MainActivity missing"
for feature in 'GraphicsProfile' 'Game profile' 'System Center' 'OpenOSINT runtime' 'WINEPREFIX' 'SYSTEM("System"'; do
  grep -Fq "$feature" "$MAIN" || fail "feature marker missing: $feature"
done
pass "Project metadata and 1.17 feature markers"

bash -n tools/bootstrap-libtermux.sh
bash -n tools/verify-libtermux-fix.sh
pass "Shell scripts"

if command -v java >/dev/null 2>&1; then
  JAVA_MAJOR=$(java -version 2>&1 | sed -n 's/.*version "\([0-9]*\).*/\1/p' | head -n1)
  [[ "$JAVA_MAJOR" == "17" || "$JAVA_MAJOR" == "18" || "$JAVA_MAJOR" == "19" || "$JAVA_MAJOR" == "20" || "$JAVA_MAJOR" == "21" || "$JAVA_MAJOR" == "22" || "$JAVA_MAJOR" == "23" || "$JAVA_MAJOR" == "24" || "$JAVA_MAJOR" == "25" || "$JAVA_MAJOR" == "26" ]] || fail "Unsupported Java runtime: $JAVA_MAJOR"
  pass "Java runtime: $JAVA_MAJOR"
fi

if [[ -d vendor/libtermux ]]; then
  bash tools/verify-libtermux-fix.sh
else
  echo "[Legitiv VERIFY] NOTE: vendor/libtermux is not present yet; bootstrap step will fetch it."
fi

pass "Compatibility gate passed; build step may now run."

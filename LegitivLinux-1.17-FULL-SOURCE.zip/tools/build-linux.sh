#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
GRADLE_VERSION="9.4.1"
GRADLE_DIR="$ROOT/.cache/gradle-$GRADLE_VERSION"
GRADLE_BIN="$GRADLE_DIR/bin/gradle"

need_cmd() { command -v "$1" >/dev/null 2>&1; }

if ! need_cmd git || ! need_cmd unzip || ! need_cmd curl || ! need_cmd dpkg-deb; then
  if need_cmd pacman; then
    echo "[Legitiv] Installing missing Arch/CachyOS packages..."
    sudo pacman -S --needed git unzip curl ca-certificates dpkg
  elif need_cmd apt-get; then
    echo "[Legitiv] Installing missing Debian/Ubuntu packages..."
    sudo apt-get update
    sudo apt-get install -y git unzip curl ca-certificates dpkg
  else
    echo "Install git, unzip, curl, ca-certificates and dpkg-deb, then rerun." >&2
    exit 1
  fi
fi

if ! need_cmd java; then
  if need_cmd pacman; then
    sudo pacman -S --needed jdk17-openjdk
  elif need_cmd apt-get; then
    sudo apt-get update
    sudo apt-get install -y openjdk-17-jdk
  else
    echo "JDK 17 is required." >&2
    exit 1
  fi
fi

JAVA_MAJOR="$(java -version 2>&1 | awk -F '[\".]' '/version/ {print $2; exit}')"
if [[ "${JAVA_MAJOR:-0}" != "17" ]]; then
  echo "JDK 17 is required for this release build; detected Java ${JAVA_MAJOR:-unknown}." >&2
  exit 1
fi

if need_cmd gradle; then
  GRADLE_CMD=(gradle)
else
  if [[ ! -x "$GRADLE_BIN" ]]; then
    mkdir -p "$ROOT/.cache"
    archive="$ROOT/.cache/gradle-$GRADLE_VERSION-bin.zip"
    echo "[Legitiv] Downloading Gradle $GRADLE_VERSION..."
    curl -fL --retry 3 --connect-timeout 20 \
      "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" \
      -o "$archive"
    rm -rf "$GRADLE_DIR" "$ROOT/.cache/gradle-$GRADLE_VERSION-unpack"
    mkdir -p "$ROOT/.cache/gradle-$GRADLE_VERSION-unpack"
    unzip -q "$archive" -d "$ROOT/.cache/gradle-$GRADLE_VERSION-unpack"
    mv "$ROOT/.cache/gradle-$GRADLE_VERSION-unpack/gradle-$GRADLE_VERSION" "$GRADLE_DIR"
    rm -rf "$ROOT/.cache/gradle-$GRADLE_VERSION-unpack"
  fi
  GRADLE_CMD=("$GRADLE_BIN")
fi

chmod +x ./tools/bootstrap-libtermux.sh ./tools/verify-release.sh ./tools/verify-libtermux-fix.sh
./tools/bootstrap-libtermux.sh
./tools/verify-release.sh
"${GRADLE_CMD[@]}" --version | sed -n '1,12p'
"${GRADLE_CMD[@]}" --no-daemon --stacktrace :app:assembleDebug

APK="$(find app/build/outputs/apk/debug -maxdepth 1 -type f -name '*.apk' -print -quit)"
if [[ -z "$APK" ]]; then
  echo "Build finished but APK was not found." >&2
  exit 1
fi

sha256sum "$APK"
echo
echo "APK готов: $ROOT/$APK"

#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
VENDOR="$ROOT/vendor/libtermux"
REPO="https://github.com/libtermux/libtermux-android.git"
REF="${LIBTERMUX_REF:-3a7e2ae63c4824fac384769c9afb8bc579458da9}"

mkdir -p "$ROOT/vendor"

if [[ -d "$VENDOR/.git" ]]; then
  echo "[Legitiv] Preparing LibTermux source ($REF)..."
  git -C "$VENDOR" fetch --depth 1 origin "$REF" || git -C "$VENDOR" fetch --depth 1 origin main
  git -C "$VENDOR" checkout -q "$REF" 2>/dev/null || git -C "$VENDOR" checkout -q FETCH_HEAD
else
  echo "[Legitiv] Downloading LibTermux source ($REF)..."
  rm -rf "$VENDOR"
  if [[ "$REF" =~ ^[0-9a-f]{40}$ ]]; then
    git clone --depth 1 "$REPO" "$VENDOR"
    git -C "$VENDOR" fetch --depth 1 origin "$REF"
    git -C "$VENDOR" checkout -q "$REF"
  else
    git clone --depth 1 --branch "$REF" "$REPO" "$VENDOR"
  fi
fi

CORE_LOGGER="$VENDOR/core/src/main/kotlin/com/libtermux/utils/Logger.kt"
DS_FILE="$VENDOR/os/src/main/kotlin/com/libtermux/os/settings/DistroSettings.kt"
DISPLAY_FILE="$VENDOR/os/src/main/kotlin/com/libtermux/os/gui/compose/DistroDisplay.kt"
OS_CONFIG="$VENDOR/os/src/main/kotlin/com/libtermux/os/OsConfig.kt"
VNC_FILE="$VENDOR/os/src/main/kotlin/com/libtermux/os/gui/vnc/VncClient.kt"

# This logger is consumed by :os. In a composite build, Kotlin 'internal'
# visibility is module-scoped and therefore blocks those calls.
if [[ -f "$CORE_LOGGER" ]]; then
  sed -i -E 's/^internal object TermuxLogger/object TermuxLogger/' "$CORE_LOGGER"
fi


# OsConfig references the shared @TermuxDsl marker from :core.
# Some upstream snapshots omit the import, which becomes an unresolved reference
# under the composite/source build used by Legitiv.
if [[ -f "$OS_CONFIG" ]]; then
  if grep -q '^@TermuxDsl' "$OS_CONFIG" && ! grep -q '^import com\.libtermux\.TermuxDsl$' "$OS_CONFIG"; then
    sed -i '2i import com.libtermux.TermuxDsl' "$OS_CONFIG"
  fi
fi

# DataStore PreferencesKey helpers used by current AndroidX APIs.
if [[ -f "$DS_FILE" ]]; then
  sed -i \
    -e 's/intKey/intPreferencesKey/g' \
    -e 's/stringKey/stringPreferencesKey/g' \
    -e 's/booleanKey/booleanPreferencesKey/g' \
    "$DS_FILE"
fi

# Compose DrawScope.drawImage expects IntSize, not Size.
if [[ -f "$DISPLAY_FILE" ]]; then
  grep -q 'import kotlin.math.roundToInt' "$DISPLAY_FILE" || sed -i '1a import kotlin.math.roundToInt' "$DISPLAY_FILE"
  python3 - "$DISPLAY_FILE" <<'PY'
from pathlib import Path
p = Path(__import__('sys').argv[1])
s = p.read_text()
s = s.replace(
    'dstSize = Size(size.width / scale, size.height / scale),',
    'dstSize = IntSize((size.width / scale).roundToInt(), (size.height / scale).roundToInt()),'
)
p.write_text(s)
PY
fi

# In suspend readLoop(), use the current coroutine context for isActive.
if [[ -f "$VNC_FILE" ]]; then
  grep -q 'import kotlinx.coroutines.currentCoroutineContext' "$VNC_FILE" || sed -i '/^import kotlinx.coroutines.\*/a import kotlinx.coroutines.currentCoroutineContext' "$VNC_FILE"
  sed -i 's/while (isActive && _state.value is VncState.Connected)/while (currentCoroutineContext().isActive && _state.value is VncState.Connected)/' "$VNC_FILE"
fi

if ! command -v dpkg-deb >/dev/null 2>&1; then
  echo "[Legitiv] dpkg-deb is required to extract the official Termux proot package." >&2
  echo "[Legitiv] Arch/CachyOS: sudo pacman -S dpkg" >&2
  echo "[Legitiv] Debian/Ubuntu: sudo apt-get install -y dpkg" >&2
  exit 1
fi

printf 'LibTermux ref: %s\n' "$(git -C "$VENDOR" rev-parse HEAD)" > "$ROOT/vendor/LIBTERMUX_REF.txt"
echo "[Legitiv] LibTermux prepared: $(git -C "$VENDOR" rev-parse --short HEAD)"

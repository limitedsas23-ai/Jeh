# Legitiv 1.17 — сборка на CachyOS / Arch Linux

```bash
sudo pacman -Syu
sudo pacman -S --needed git unzip curl ca-certificates dpkg jdk17-openjdk
java -version
```

Затем:

```bash
cd /путь/к/LegitivLinux-1.17
chmod +x tools/build-linux.sh
./tools/build-linux.sh
```

Скрипт:
- проверяет JDK 17;
- ставит host tools при необходимости;
- использует установленный Gradle или скачивает Gradle 9.4.1;
- получает pinned LibTermux;
- применяет compatibility-патчи;
- запускает `verify-release.sh`;
- собирает `:app:assembleDebug`;
- печатает SHA-256 APK.

APK:
`app/build/outputs/apk/debug/app-debug.apk`

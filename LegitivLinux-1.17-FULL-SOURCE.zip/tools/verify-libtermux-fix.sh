#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
VENDOR="$ROOT/vendor/libtermux"
for f in \
  "$VENDOR/core/src/main/kotlin/com/libtermux/utils/Logger.kt" \
  "$VENDOR/os/src/main/kotlin/com/libtermux/os/OsConfig.kt" \
  "$VENDOR/os/src/main/kotlin/com/libtermux/os/settings/DistroSettings.kt" \
  "$VENDOR/os/src/main/kotlin/com/libtermux/os/gui/compose/DistroDisplay.kt" \
  "$VENDOR/os/src/main/kotlin/com/libtermux/os/gui/vnc/VncClient.kt"; do
  test -f "$f" || { echo "Missing $f"; exit 1; }
done
grep -q '^object TermuxLogger' "$VENDOR/core/src/main/kotlin/com/libtermux/utils/Logger.kt"
grep -q '^import com.libtermux.TermuxDsl$' "$VENDOR/os/src/main/kotlin/com/libtermux/os/OsConfig.kt"
! grep -Eq '\b(intKey|stringKey|booleanKey)\b' "$VENDOR/os/src/main/kotlin/com/libtermux/os/settings/DistroSettings.kt"
grep -q 'dstSize = IntSize' "$VENDOR/os/src/main/kotlin/com/libtermux/os/gui/compose/DistroDisplay.kt"
grep -q 'currentCoroutineContext().isActive' "$VENDOR/os/src/main/kotlin/com/libtermux/os/gui/vnc/VncClient.kt"
echo "LibTermux compatibility patches verified."

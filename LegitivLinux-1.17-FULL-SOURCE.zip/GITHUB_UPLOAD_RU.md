# Загрузка Legitiv 1.17 в GitHub

Репозиторий: `limitedsas23-ai/Jeh`.

Для чистого релиза загрузите содержимое папки `LegitivLinux-1.17` в корень репозитория, чтобы `.github/workflows/build-apk.yml` находился именно в `.github/workflows/`.

Workflow:

1. JDK 17;
2. Gradle 9.4.1 через `gradle/actions/setup-gradle@v6`;
3. Android SDK 36 / Build Tools 36.0.0;
4. `dpkg` для официального Termux `proot`;
5. pinned LibTermux commit `3a7e2ae63c4824fac384769c9afb8bc579458da9`;
6. compatibility gate;
7. `:app:assembleDebug`;
8. проверка APK metadata и SHA-256;
9. upload artifact.

После загрузки: **Actions → Build Legitiv 1.17 → Run workflow**.

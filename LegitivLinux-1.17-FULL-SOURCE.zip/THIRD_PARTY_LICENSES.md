# Third-party licenses

## LibTermux

Project: https://github.com/libtermux/libtermux-android
License: Apache License 2.0

Legitiv does not bundle the LibTermux source in this archive. The build script downloads it from the upstream repository into `vendor/libtermux` before compilation.


## 1.17 research references
- Winlator WB64 — https://github.com/winebox64/winlator (Apache-2.0)
- Box64 — https://github.com/ptitSeb/box64
- FEX — https://github.com/FEX-Emu/FEX
- LibTermux — https://github.com/libtermux/libtermux-android

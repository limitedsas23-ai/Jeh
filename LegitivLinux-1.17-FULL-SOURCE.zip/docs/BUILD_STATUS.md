# Build status — Legitiv 1.17

## Проверено в этом архиве

- версия приложения: 1.17 / versionCode 117;
- Gradle wrapper properties: 9.4.1;
- compileSdk/targetSdk: 36;
- shell scripts проходят `bash -n`;
- compatibility gate проходит статические проверки;
- архив ZIP проходит `unzip -t`;
- проверены UI-маркеры Windows Hub, Game Profile, System Center, OpenOSINT runtime и стеклянной кастомизации;
- GitHub Actions workflow рассчитан на JDK 17 + Gradle 9.4.1 + Android SDK 36.

## Не заявляется как проверенное

Полная Android-сборка APK в этом окружении не запускалась: нет рабочего Android SDK/Gradle cache и исходящей сетевой загрузки всех зависимостей. Поэтому этот архив — подготовленный исходник и воспроизводимый CI-рецепт, а не уже подтверждённый APK.

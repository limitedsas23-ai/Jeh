# Аудит Legitiv 1.17

Последний известный CI запуск исходного проекта падал на `:libtermux:os:compileDebugKotlin`. По реальному логу были обнаружены: `TermuxLogger` с `internal` visibility, отсутствие импорта `TermuxDsl`, `Size` вместо `IntSize`, и использование `isActive` без `currentCoroutineContext()`.

В `tools/bootstrap-libtermux.sh` добавлены точечные compatibility-патчи и pin на commit `3a7e2ae63c4824fac384769c9afb8bc579458da9`.

## 1.17 функциональный слой

- стеклянный интерфейс, 8 тем, включая Orange/Peach/Amber/Violet/Carbon;
- выбор обоев, dim, blur, transparency;
- Linux profiles + Desktop/VNC;
- Linux Apps launcher;
- Windows Hub с hardware/runtime preflight;
- game profile с WINEPREFIX, renderer, Box64 preset, DXVK/VKD3D, launch args и env vars;
- System Center и экспорт диагностики;
- Async OSINT + установка/запуск OpenOSINT внутри Ubuntu;
- Network Lab без перехвата чужого трафика и без извлечения чужих Wi-Fi credentials.

## 1.17 compatibility model

Windows Hub не обещает универсальную совместимость. На ARM64 x86_64 Windows-программы требуют дополнительного userspace-слоя (Box64 или FEX) и совместимого Wine/Proton. Графическая часть зависит от Vulkan/Mesa/GPU driver и конкретного приложения.

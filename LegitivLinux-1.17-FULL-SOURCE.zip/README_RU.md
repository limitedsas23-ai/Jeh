# Legitiv Linux 1.17

Legitiv Linux — Android-приложение с единым интерфейсом для rootless Linux на Android: встроенный Termux bootstrap ARM64, PRoot, терминал и графический Linux Desktop через VNC/RFB.

## Что нового в 1.17

- новый стеклянный UI с полупрозрачными панелями;
- темы **Neon**, **Orange**, **Peach**, **Ice**, **Matrix**;
- пользовательские обои с затемнением и мягким blur-фоном;
- настройка прозрачности панелей;
- единая боковая навигация Linux / Terminal / Desktop / Async OSINT / Настройки;
- Async OSINT: параллельные DNS-проверки, RDAP для IP, HTTP HEAD для URL и обычный публичный веб-поиск;
- отдельная ссылка на официальный OpenOSINT для расширенных authorized security research сценариев;
- pinned-версия LibTermux и автоматические совместимые патчи для Gradle/Kotlin;
- Gradle 9.4.1 для проекта и JDK 17 для сборки.

## Async OSINT и приватность

OpenOSINT — независимый MIT-проект с CLI/Web/MCP интерфейсом и инструментами для email, телефона, доменов, IP и других источников. В Legitiv встроена безопасная часть: сетевые проверки запускаются по нажатию пользователя, а Email/телефон передаются только в обычный веб-поиск. Закрытые базы, скрытые аккаунты и установление личности внутри Legitiv не выполняются.

Официальный OpenOSINT: https://github.com/OpenOSINT/OpenOSINT

## Сборка

Для CachyOS смотрите `tools/README_BUILD_RU.md`.

Готовый debug APK после успешной сборки:

`app/build/outputs/apk/debug/app-debug.apk`
